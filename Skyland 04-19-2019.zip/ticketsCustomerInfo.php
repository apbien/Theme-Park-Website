<?php require_once('config.php') ?>
<?php include('tickets_server.php'); ?>


<?php require_once('includes/head_section.php') ?>
<?php include('includes/navbar.php') ?>

		<!-- navbar -->

	<!--Next Section -->
  
	
        <br> <br> <br>
        <div class="header">
			<h2>Enter your information</h2>
		</div>

        
		<form method="post" action="ticketsCustomerInfo.php">
		

            
        <div class="input-group">
			<label>First Name</label><br>
			<input type="text" name="firstname" value="<?php echo $first; ?>" required>
		</div>



		<div class="input-group">
			<label>Last name</label><br>
			<input type="text" name="lastname" value="<?php echo $last; ?>" required>
		</div>

           <div class="input-group">
            
         <label>Date of Birth</label><br>
            <input type="date" name="dob" value="<?php echo $dob; ?>" required>
		</div>
            
		<div class="input-group">
			<label>Phone Number</label><br>
			<input type="number" name="phone" value="<?php echo $phone; ?>" required>
		</div>
            
        <div class="input-group">
			<label>Email</label><br>
			<input type="text" name="email" value="<?php echo $email; ?>" required>
		</div>

            
        <p>
            <button type="submit" name="submit" class="btn">submit</button>

        </form>
</body>
</html>




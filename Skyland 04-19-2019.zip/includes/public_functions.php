	<!-- THIS WILL HOLD ALL PHP FUNCTIONS FOR PUBLIC AREA-->
<?php 
/* * * * * * * * * * * * * * *
* Returns all attractions
* * * * * * * * * * * * * * */
function getAttraction() {
	// use global $conn object in function
	global $conn;
	$sql = "SELECT * FROM attraction"; 
	$result = mysqli_query($conn, $sql);

	// fetch all posts as an associative array 
	$rides = mysqli_fetch_all($result, MYSQLI_ASSOC);

	return $rides;
}

/* * * * * * * * * * * * * * *
* Returns all gift shops
* * * * * * * * * * * * * * */
function getgiftShops() {
	// use global $conn object in function
	global $conn;
	$sql = "SELECT * FROM gift_shop"; 
	$result = mysqli_query($conn, $sql);

	// fetch all posts as an associative array 
	$gifts = mysqli_fetch_all($result, MYSQLI_ASSOC);

	return $gifts;
}

/* * * * * * * * * * * * * * *
* Returns all Restaurants
* * * * * * * * * * * * * * */
function getRestaurant() {
	// use global $conn object in function
	global $conn;
	$sql = "SELECT * FROM restaurant"; 
	$result = mysqli_query($conn, $sql);

	// fetch all posts as an associative array 
	$restaurant = mysqli_fetch_all($result, MYSQLI_ASSOC);

	return $restaurant;
}

/* * * * * * * * * * * * * * *
* Returns all venues
* * * * * * * * * * * * * * */
function getVenue() {
	// use global $conn object in function
	global $conn;
	$sql = "SELECT * FROM venue"; 
	$result = mysqli_query($conn, $sql);

	// fetch all posts as an associative array 
	$venue = mysqli_fetch_all($result, MYSQLI_ASSOC);

	return $venue;
}

// more functions to come here ...
?>
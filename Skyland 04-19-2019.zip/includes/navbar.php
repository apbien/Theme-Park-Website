		
			<nav id="navigation">
				<ul id="nav">
					<li><a href="index.php">Home</a></li>
					<li><a href="giftshop_home.php">Gift Shops</a></li>
					<li><a href="restaurant_home.php">Restaurants</a></li>
					<li><a href="venue_home.php">Venues</a></li>
					<li><a href="rides_home.php">Rides</a></li>
					<li><a href="events.php">Events</a></li>
					<li><a href="tickets.php">Tickets</a></li>
				</ul>
			</nav>


<?php if (isset($_SESSION['employee']['email'])) { ?>
	<div class="logged_in_info">
		<span>welcome <?php echo $_SESSION['employee']['email'] ?></span>
		|
		<span><a href="logout.php">logout</a></span>
	</div>
<?php }

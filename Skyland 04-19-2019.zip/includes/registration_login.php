<?php 
	// variable declaration
	$firstname = "";
	$middlename = "";
	$lastname = "";
	$dob = "";
	$gender = "";
	$phone = "";
	$street = "";
	$state = "";
	$zip = "";
	$email = "";
	$role = "";
	$password_1 = "";
	$password_2 = "";
	$_SESSION['bday'] = "";
	$errors = array();

	// REGISTER USER
	if(isset($_POST['reg_user'])){
	//value for Position (Blank)
		$role = ($_POST['roleOption']);
		$firstname = ($_POST['firstname']);
		$middlename = ($_POST['middlename']);
		$lastname = ($_POST['lastname']);
		$dob = ($_POST['dob']);
		$gender = ($_POST['gender']);
		$phone = ($_POST['phone']);
		$street = ($_POST['street']);
		$statename = ($_POST['statename']);
		$zip = ($_POST['zip']);
		$email = ($_POST['email']);
		$password_1 = ($_POST['password_1']);
		$password_2 = ($_POST['password_2']);
		$_SESSION['bday'] = ($_POST['dob']);

		if(empty($firstname)){
			array_push($errors, "First name is required");
		}

		if(empty($lastname)){
			array_push($errors, "Last name is required");
		}

		if(empty($dob)){
			array_push($errors, "Date of Birth is required");
		}

		if(empty($phone)){
			array_push($errors, "Phone number is required");
		}

		if(empty($street)){
			array_push($errors, "Address is required");
		}

		if(empty($statename)){
			array_push($errors, "State is required");
		}

		if(empty($zip)){
			array_push($errors, "Zip Code is required");
		}

		if(empty($email)){
			array_push($errors, "Email is required");
		}

		if(empty($password_1)){
			array_push($errors, "Password is required");
		}

		if($password_1 != $password_2){
			array_push($errors, "Password does not match");
		}

		$user_check_query = "SELECT * FROM employee WHERE email='$email' LIMIT 1";

		$result = mysqli_query($conn, $user_check_query);
		$user = mysqli_fetch_assoc($result);

		if ($user) { // if user exists
			if ($user['email'] == $email) {
			  array_push($errors, "Email already exists");
			}
		}
		// register user if there are no errors in the form
		if (count($errors) == 0) {
			$password = md5($password_1);//encrypt the password before saving in the database
			$query = "INSERT INTO employee (first_name, middle_name, last_name, DOB, gender,
				phone_number, street_address, state, zip_code, email, password, manager_status, active_status) VALUES ('$firstname', '$middlename', '$lastname', '$dob', '$gender', $phone, '$street', '$statename', $zip, '$email', '$password_1', 'N', 'N')";
			mysqli_query($conn, $query);

			// get id of created user
			$reg_user_id = mysqli_insert_id($conn); 

			// put logged in user into session array
			$_SESSION['employee'] = getUserById($reg_user_id);

			//User logins in, however has to wait for admin/manager to update
			$_SESSION['message'] = "You are now logged in";
				// redirect to public area
			header('location: ' . BASE_URL . '/employee/employee.php');
		}
	}

	// LOG USER IN
	if (isset($_POST['login_btn'])) {
		$email = $_POST['email'];
		$password = $_POST['password'];

		if (empty($email)) { array_push($errors, "Email required"); }
		if (empty($password)) { array_push($errors, "Password required"); }
		if (empty($errors)) {
			$sql = "SELECT * FROM employee WHERE email='$email' AND password='$password'";

			$result = mysqli_query($conn, $sql);
			if (mysqli_num_rows($result) > 0) {
				// get id of created user
				$reg_user_id = mysqli_fetch_assoc($result)['employee_id']; 

				// put logged in user into session array
				$_SESSION['employee'] = getUserById($reg_user_id); 

				// if user is admin, redirect to admin area
				if ( in_array($_SESSION['employee']['manager_status'], ["A"])) {
					$_SESSION['message'] = "You are now logged in";
					// redirect to admin area
					header('location: ' . BASE_URL . '/employee/employee.php');
					exit(0);
				} else {
					$_SESSION['message'] = "You are now logged in";
					// redirect to public area
					header('location: ' . BASE_URL . '/employee/employee.php');			
					exit(0);
				}
			} 	
			else {
				array_push($errors, 'Wrong credentials');
			}
		}
	}
	// escape value from form
	function esc(String $value)
	{	
		// bring the global db connect object into function
		global $conn;

		$val = trim($value); // remove empty space sorrounding string
		$val = mysqli_real_escape_string($conn, $value);

		return $val;
	}
	// Get user info from user id
	function getUserById($num)
	{
		global $conn;
		$sql = "SELECT * FROM employee WHERE employee_id=$num LIMIT 1";

		$result = mysqli_query($conn, $sql);
		$user = mysqli_fetch_assoc($result);

		// returns user in an array format: 
		// ['id'=>1 'username' => 'Awa', 'email'=>'a@a.com', 'password'=> 'mypass']
		return $user; 
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Themepark</title>
		<link rel="stylesheet" type="text/css" href="static/css/style_navigation.css"/>

	<title>ThemePark | Home </title>
	</head>
	<body>
		<div id="wrapper">
			<div id="banner">

				<?php

					if(isset($_SESSION['employee'])){
						echo '<div class="menubuttons">
					<ul>
						<li><a href="employee/employee.php">EMPLOYEE PAGE</a> </li>
						<li><a href="logout.php">LOGOUT </a> </li>
					</ul>
				</div>';
					}
					else{
						echo '<div class="menubuttons">
					<ul>
						<li><a href="apply.php">APPLY</a> </li>
						<li><a href="login.php">LOGIN </a> </li>
					</ul>
				</div>';
					}

				?>

				<div class = "parkname">
					SKYLAND
				</div>

			</div>
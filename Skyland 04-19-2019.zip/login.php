<?php  include('config.php'); ?>
<?php  include('includes/registration_login.php'); ?>
<?php  include('includes/head_section.php'); ?>
	<title>ThemePark | Sign in </title>
</head>
<body>
<div class="container">
	<!-- Navbar -->
	<?php include( ROOT_PATH . '/includes/navbar.php'); ?>
	<!-- // Navbar -->
		<div class="login_header">
			<h2>Log Into Account</h2>
		</div>
		<form method="post" action="login.php" >
		<?php include(ROOT_PATH . '/includes/errors.php') ?>
		<div class="login_customer">
			<label>Email Address</label>
			<input type="text" name="email" value="<?php echo $email; ?>" value="" placeholder="Email">
		</div>
		<div class="login_customer">
			<label>Password</label>
			<input type="password" name="password" placeholder="Password">
		</div>
		<div class="login_customer">
			<button type="submit" class="btn" name="login_btn">Login</button>
		</div>
		<p>
			Not yet a member? <a href="apply.php">Sign up</a>
		</p>
	</form>
</div>
<!-- // container -->

<!-- Footer -->
	<?php include( ROOT_PATH . '/includes/footer.php'); ?>
<!-- // Footer -->
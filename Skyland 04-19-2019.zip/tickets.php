<?php require_once('config.php') ?>
<?php include('tickets_server.php'); ?>

<?php require_once('includes/head_section.php') ?>

		<!-- navbar -->
<?php include('includes/navbar.php') ?>
        


		<!-- Next Section  -->

		<div class="header">
			<h2>Tickets</h2>
		</div>

		<form method = "post" action ="tickets.php">
		<div>
			<label>Chooose your ticket type <br>  <br></label>
        
			<input type="radio" name="normalPass" value="Y"  required > Single Day Ticket $30 <br>
            <input type="radio" name="normalPass" value="N"  required > Fast pass $40 <br>
		</div>
            
            <div>
                <br>
			<label>Chooose date <br> </label>
        
                <br>  
		<input type="date" name="date" placeholder="YYYY-MM-DD" required title="Enter a date"/>
		</div>
            
            <br>  
            
            <div>
			<label>Do you need Parking? <br>  <br></label>
        
			<input type="radio" name="parking" value="Y" required > Yes (price =$10) <br>
            <input type="radio" name="parking" value="N"  required >  No <br>
            </div>
            
            <br>  <br>
            
        <div> <label>If yes choose a parking lot from this list:</label> <br>
        <br>  

            <select name="lots">
			<option value =""></option>
            <option value="4A">4A</option>
            <option value="5A">5A</option>
            </select>
                     
            </div>
            
        <dir>
		<div> <label>How many tickets?</label> <br>
        <br>  

            <select name="amount">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
			<option value="11">11</option>
            <option value="12">12</option>
            <option value="13">13</option>
            <option value="14">14</option>
            <option value="15">15</option>
            <option value="16">16</option>
            <option value="17">17</option>
            <option value="18">18</option>
            <option value="19">19</option>
            <option value="20">20</option>
            </select>
                     
            </div>
            
        <dir>
			<p>
                 <button type="submit" name="reserve" class="btn">Reserve ticket</button>
			</p>
        </dir>
            


		</form>
<?php
	$count = 0;
	$now = new DateTime();
	$now_time = $now->format('Y-m-d H:i:s');
	if(isset($_POST['reserve'])){
		$new_date = date('Y-m-d', strtotime($_POST['date']));
		$_SESSION['pass'] = $_POST['normalPass'];
		$_SESSION['date'] = $new_date;
		$_SESSION['parking'] = $_POST['parking'];
		$_SESSION['parking_loc'] = $_POST['lots'];
		$_SESSION['amount'] = $_POST['amount'];

		
		if($_SESSION['parking']== 'Y' && $_SESSION['parking_loc'] == ""){
			echo ("A parking location must be chosen if you are choosing to buy a parking pass.");
			$count = 1;
		}
		if($new_date < $now_time){
			echo("Please choose a date that is not in the past");
			$count = 1;
		}

		if($count == 0){
			header('location: ticketsCustomerInfo.php');
		}
	}
	

?>
	</body>

</html>





	<!-- ROOT PATH IS SET TO PHYSICAL ADDRESS-->
<?php require_once('config.php') ?>
<!-- config.php should be here as the first include  -->

<?php require_once( ROOT_PATH . '/includes/public_functions.php') ?>

<!-- Retrieve all rides from database, get Attraction function -->
<?php $rides = getAttraction(); ?>
<?php require_once('includes/head_section.php') ?>

		<!-- navbar -->
			<?php include( ROOT_PATH . '/includes/navbar.php') ?>
				<!-- // navbar -->

<!-- Next Section  -->

		<div class="content">
			<h2 class="content-title">Rides</h2>
			<hr>
			<!-- more content still to come here ... -->

			<!-- Add this ... -->
		<?php foreach ($rides as $ride): ?>
		<div class="post" style="margin-left: 5px;">
				<div class="ride_info">
					<h3><?php echo $ride['name'] ?></h3>
					<div class="info">
						<label>Descripition:</label>
						<p><?php echo $ride['description'] ?></p>
						<label>Ride Requirement:</label>
						<p><?php echo $ride['ride_requirement'] ?></p>
						<label>Date Built:</label>
						<p><?php echo $ride['date_built'] ?></p>
						<label>Park Location: </label>
						<p><?php echo $ride['location_id_fk'] ?></p>

					</div>
				</div>
		</div>
		<?php endforeach ?>
		</div>

	<!-- footer -->
<?php include( ROOT_PATH . '/includes/footer.php') ?>
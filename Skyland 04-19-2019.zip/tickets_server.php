<?php

$customer_id_fk = '';
$normalPass = '';
$date = '';
$price = '';
$parking ='';
$cost = '';
$amount = '';
$amount = '';
$first = '';
$last = '';
$dob = '';
$phone = '';
$email = '';


if(isset($_POST['submit'])){

	//value for Position (Blank)
		$first = $_POST['firstname'];
		$last = $_POST['lastname'];
		$dob = $_POST['dob'];
		$phone = $_POST['phone'];
		$email = $_POST['email'];
		echo $first;

		$normalPass = $_GET['pass'];
		$date = $_SESSION['date'];
		$parking =$_SESSION['parking'];
		$location = $_SESSION['parking_loc'];
		$amount = $_SESSION['amount'];
		echo $normalPass;
		
		if($normalPass== "Y" ){
			$price = 30;
		}
		 else{
			$price = 40;   
		 }
		// IF STAEMENT TO GET THE VALUE OF PRICE

		if($parking== "Y" ){
			$cost = 10;

		}
    
    // Insert values from ticketCustomerInfo.php into the customer table
	
    $reg = "INSERT INTO customer( first_name, last_name, email, phone_number, DOB) VALUES ('$first','$last','$email','$phone','$dob')";
    
    mysqli_query($conn, $reg);
    
    //This checks if we have a customer with the email entered already exits in the database.
    $get = "SELECT customer_id FROM customer WHERE customer.email = '$email' ";
    $result = mysqli_query($conn,$get);
    
    while($row = mysqli_fetch_assoc($result)){
        $customer_id_fk = $row['customer_id'];
    }
    
	$sql1 = "INSERT INTO tickets(price,fastpass,date, customer_fk_id)
	VALUES($price,'$normalPass','$date',$customer_id_fk)";
	for($i = 0; $i<$amount; $i++){
		mysqli_query($conn, $sql1);
	}
	if($parking == 'Y'){
		$sql2= "INSERT INTO parking(cost,location_id_fk,customer_id_fk)
		VALUES($cost,'$location',$customer_id_fk)" ;
		mysqli_query($conn, $sql2);
	
	} 
	echo "Ticket was successfully bought!";
	header('location: index.php');
}

// After checking if customer is in the database, add customer_id in ticket table as customer_id_fk




?>
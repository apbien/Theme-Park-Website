<?php  include('config.php'); ?>
<!-- Source code for handling registration and login -->
<?php  include('includes/registration_login.php'); ?>

<?php include('includes/head_section.php'); ?>

<title>Themepark | Sign up </title>
</head>
<body>
<div class="container">
	<!-- Navbar -->
		<?php include( ROOT_PATH . '/includes/navbar.php'); ?>
	<!-- // Navbar -->

	<div class="header">
			<h2>Application</h2>
		</div>

		<form method = "post" action ="apply.php">

		<?php include(ROOT_PATH . '/includes/errors.php') ?>
		<div>
			<label>Position Applying</label>
			<select name = "roleOption">
  				<option value="Restaurant_Employee">Restaurant Employee</option>
  				<option value="GiftShop_Employeee">GiftShop Employeee</option>
  				<option value="Marketing_Employee">Marketing Employee</option>
  				<option value="Attraction_Employee">Attraction Employee</option>
  				<option value="Maintenace_Employee">Maintenace Employee</option>
  				<option value="Event_Employee">Event Employee</option>
			</select>
		</div>

		<div class="input-group">
			<label>First Name</label>
			<input type="text" name="firstname">
		</div>

		<div class="input-group">
			<label>Middle name (Optional)</label>
			<input type="text" name="middlename">
		</div>

		<div class="input-group">
			<label>Last name</label>
			<input type="text" name="lastname">
		</div>

		<div class="input-group">
			<label>Birthday</label>
			<input type="date" name="dob">
		</div>

		<div>
			<label>Gender:</label>
			<input type="radio" name="gender" value="M" checked> Male<br>
  			<input type="radio" name="gender" value="F"> Female<br>
  			<input type="radio" name="gender" value="O"> Other
		</div>

		<div class="input-group">
			<label>Phone Number</label>
			<input type="number" name="phone" >
		</div>

		<div class="input-group">
			<label>Address</label>
			<input type="text" name="street">
		</div>

		<div class="input-group">
			<label>State</label>
			<input type="text" name="statename">
		</div>

		<div class="input-group">
			<label>Zip Code</label>
			<input type="text" name="zip">
		</div>

		<div class="input-group">
			<label>Email</label>
			<input type="email" name="email">
		</div>

		<div class="input-group">
			<label>Password</label>
			<input type="password" name="password_1">
		</div>

		<div class="input-group">
			<label>Confirm Password</label>
			<input type="password" name="password_2">
		</div>

		<dir>
			<p>
				<button type="submit" class="btn" name="reg_user">Apply</button>
			</p>
		</dir>
		<p>
			Already a Employee? <a href="login.php">Sign in</a>
		</p>

		</form>
</div>
<!-- // container -->
<!-- Footer -->
	<?php include( ROOT_PATH . '/includes/footer.php'); ?>
<!-- // Footer -->
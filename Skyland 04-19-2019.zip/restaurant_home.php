	<!-- ROOT PATH IS SET TO PHYSICAL ADDRESS-->
<?php require_once('config.php') ?>
<!-- config.php should be here as the first include  -->

<?php require_once( ROOT_PATH . '/includes/public_functions.php') ?>

<!-- Retrieve all rides from database, get Attraction function -->
<?php $restaurants = getRestaurant(); ?>
<?php require_once('includes/head_section.php') ?>

		<!-- navbar -->
			<?php include( ROOT_PATH . '/includes/navbar.php') ?>
				<!-- // navbar -->

<!-- Next Section  -->

		<div class="content">
			<h2 class="content-title">Restaurants</h2>
			<hr>
			<!-- more content still to come here ... -->

			<!-- Add this ... -->
		<?php foreach ($restaurants as $restaurant): ?>
		<div class="post" style="margin-left: 5px;">
				<div class="restaurants_info">
					<h3><?php echo $restaurant['restaurant_name'] ?></h3>
					<div class="info">
						<label>Menu Items</label>
						<p><?php echo $restaurant['menu_items'] ?></p>
						<label>Opening Time:</label>
						<p><?php echo $restaurant['opening_time'] ?></p>
						<label>Closing Time:</label>
						<p><?php echo $restaurant['closing_time'] ?></p>
						<label>Park Location: </label>
						<p><?php echo $restaurant['location_id_fk'] ?></p>

					</div>
				</div>
		</div>
		<?php endforeach ?>
		</div>

	<!-- footer -->
<?php include( ROOT_PATH . '/includes/footer.php') ?>
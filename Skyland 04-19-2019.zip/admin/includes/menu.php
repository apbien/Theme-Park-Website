<div class="menu">
	<div class="card">
		<div class="card-header">
			<h2>Actions</h2>
		</div>
		<div class="card-content">
			<a href="<?php echo BASE_URL . 'admin/Rides.php' ?>">Manage Rides</a>
			<a href="<?php echo BASE_URL . 'admin/Shops.php' ?>">Manage Gift Shops</a>
			<a href="<?php echo BASE_URL . 'admin/users.php' ?>">Manage Users</a>
			<a href="<?php echo BASE_URL . 'admin/Restaurant.php' ?>">Manage Restaurants</a>
			<a href="<?php echo BASE_URL . 'admin/venue.php' ?>">Manage Venue Schedule</a>
			<a href="<?php echo BASE_URL . 'admin/marketing.php' ?>">Manage Marketing</a>
		</div>
	</div>
</div>
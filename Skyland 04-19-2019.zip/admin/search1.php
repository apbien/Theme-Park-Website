<?php  include('../config.php'); ?>


<!DOCTYPE html>
<html>
    <head>
        
        <title> Look Up table </title>
        <link rel="stylesheets" type="text/css" href="style.css">
        <style> 
            table,tr, th,td{
                border: 1px solid black;
            }
        </style>
    </head>
        <body>
           

<h1> Search Page </h1>
   <form>
   <button type="submit" class="btn btn-success" formaction="search.php">Return to Search</button>
  <button type="submit" class="btn btn-success" formaction="dashboard.php">Return to Admin Dashboard</button>
</form>         
<!--Attraction Search-->
            
<div class="attraction-container">
      
  <?php
    
    if(isset($_POST['submit-search'])){

        $search_dropdown= $_POST['search_dropdown'];
        $filter= $_POST['filter'];

        if($search_dropdown=="attraction" or $search_dropdown==""){
           
            echo"<h2> Results in ATTRACTION </h2>";
            $search= mysqli_real_escape_string($conn, $_POST['search']);
            if ($filter == "only_has") {
                $sql= "SELECT* FROM attraction WHERE ride_id = '$search'
            OR name='$search' 
            OR ride_requirement= '$search' 
            OR date_built ='$search' 
            OR description ='$search' 
            OR active_status ='$search' 
            OR location_id_fk ='$search' 
            OR ticket_id_fk ='$search'
            OR flag ='$search' ";
            $result= mysqli_query($conn,$sql);
            $queryResult= mysqli_num_rows($result);
            }

            else if ($filter == "contains" or $filter == ""){
                 $sql= "SELECT* FROM attraction WHERE ride_id LIKE '%$search%' 
            OR name LIKE '%$search%'
            OR ride_requirement LIKE '%$search%' 
            OR date_built LIKE '%$search%' 
            
            
            OR description LIKE '%$search%' 
            OR active_status LIKE '%$search%' 
            OR location_id_fk LIKE '%$search%' 
            OR ticket_id_fk LIKE '%$search%'
            OR flag LIKE '%$search%'";
            
            $result= mysqli_query($conn,$sql);
            $queryResult= mysqli_num_rows($result);
            }
        
        }
    }
    ?>
    
                <div class="event-container">
                
               
 
    <?php
    if($search_dropdown=="attraction" or $search_dropdown==""){
    if($queryResult >0){

         echo "<table>
                       
                       <tr>
                           
                           <th>Ride Id</th>
                           <th>Ride Name</th>
                           <th>Ride Requirements</th>
                           <th>Date Built</th>
                           <th>Descrition</th>
                           <th>Active Status</th>
                           <th> Location Id</th>
                           <th>Ticket Id</th>
                           <th>Flag</th>
        
                       </tr>";

         while($row= mysqli_fetch_assoc($result)){  
           
               echo " <tr>
                       <td> ".$row['ride_id']."</td>
                       <td> ".$row['name']."</td>
                       <td> ".$row['ride_requirement']."</td>
                       <td> ".$row['date_built']."</td>
                       <td> ".$row['description']."</td>
                       <td> ".$row['active_status']."</td>
                       <td> ".$row['location_id_fk']."</td>
                        <td> ".$row['ticket_id_fk']."</td>
                        <td> ".$row['flag']."</td>
                       
                       </tr>";
 
         }
          echo"</table>";
        }
        else{
            echo "There are no results matching your search in the attraction table ";
        }
    }
    ?>           
              
            </div>    
    
</div>
            
            
<!--Customer Search-->
            
            <div class="customer-container">
      
  <?php
    
    if(isset($_POST['submit-search'])){

         if($search_dropdown=="customer" or $search_dropdown==""){
             
            echo"<h2> Results in CUSTOMER </h2>";
            $search= mysqli_real_escape_string($conn, $_POST['search']);
            
            $sql= "SELECT* FROM customer WHERE customer_id LIKE '%$search%' 
            OR first_name LIKE '%$search%' 
            OR last_name LIKE '%$search%' 
            OR DOB LIKE '%$search%' 
            OR phone_number LIKE '%$search%' 
            OR email LIKE '%$search%'  
            OR events_id_fk LIKE '%$search%'
            OR flag LIKE '%$search%'
            ";
        
            $result= mysqli_query($conn,$sql);
            $queryResult= mysqli_num_rows($result);
         }
            
    }
    ?>
    
                <div class="event-container">
                
               
                   
 
    <?php
     if($search_dropdown=="customer" or $search_dropdown==""){
    if($queryResult >0){
         
            echo " <table>
                       
                        <tr>
                            <th>Customer Id</th>
                            <th>First Name</th>
                           <th>Last Name</th>
                           <th>DOB</th>
                           <th>Phone Number</th>
                           <th>Email</th>
                           <th>Events Id</th>
                           <th>Flag</th>
                           
                    </tr>";

                    while($row= mysqli_fetch_assoc($result)){  
                    
                    echo"
                        <tr>
                       <td> ".$row['customer_id']."</td>
                       <td> ".$row['first_name']."</td>
                       <td> ".$row['last_name']."</td>
                       <td> ".$row['DOB']."</td>
                       <td> ".$row['phone_number']."</td>
                       <td> ".$row['email']."</td>
                       <td> ".$row['events_id_fk']."</td>
                       <td> ".$row['flag']."</td>
                       
                       </tr>
                       
                      ";

         }
          echo"</table>";
        }
        else{
            echo "There are no results matching your search in the customer table";
        }
     }
    ?>
                        
            </div>    
    
</div>
            
 <!--Employee Search-->

<div class="employee-container">
      
  <?php
    
    if(isset($_POST['submit-search'])){

        if($search_dropdown=="employee" or $search_dropdown==""){
             
            echo"<h2> Results in EMPLOYEE </h2>";
            $search= mysqli_real_escape_string($conn, $_POST['search']);
            
            $sql= "SELECT* FROM employee WHERE employee_id LIKE '%$search%' 
            OR first_name LIKE '%$search%' 
            OR middle_name LIKE '%$search%' 
            OR last_name LIKE '%$search%' 
            OR DOB LIKE '%$search%' 
            OR gender LIKE '%$search%' 
            OR phone_number LIKE '%$search%' 
            OR email LIKE '%$search%' 
            OR hourly_wage LIKE '%$search%' 
            OR salary LIKE '%$search%' 
            OR street_address LIKE '%$search%' 
            OR state LIKE '%$search%'  
            OR zip_code LIKE '%$search%'
            OR giftshop_id_fk LIKE '%$search%'
            OR event_id_fk LIKE '%$search%'
            OR restaurant_id_fk LIKE '%$search%' 
            OR marketing_id_fk LIKE '%$search%' 
            OR active_status LIKE '%$search%'
            OR attraction_id_fk LIKE '%$search%' 
            OR maint_id_fk LIKE '%$search%' 
            OR hire_date LIKE '%$search%' 
            OR flag LIKE '%$search%'
            ";
            
        
            $result= mysqli_query($conn,$sql);
            $queryResult= mysqli_num_rows($result);
        }
    }
    ?>
    
    
    
    <div class="event-container">             
 
    <?php
     if($search_dropdown=="employee" or $search_dropdown==""){
    if($queryResult >0){
        
            echo "<table>
                       
                        <tr>
                           <th>Employee Id</th>
                           <th>First Name</th>
                           <th>Middle Name</th>
                           
                           <th>Last Name</th>
                           <th>DOB</th>
                           <th>Gender</th>
                           
                           <th>Phone Number</th>
                           <th>Email</th>
                           <th>Hourly wage</th>
                           
                           <th>Salary</th>
                           <th>Street Adress</th>
                           <th>State</th>
                           
                           <th>Zip Code</th>
                           
                           <th>Gift Shop ID</th>
                           <th>Event ID</th>
                           <th>Restaurant ID</th>
                           <th>Marketing ID</th>
                           <th>Active Status ID</th>
                           <th>Attraction ID</th>
                           <th>Maintenance ID</th>
                           <th>Hire Date</th>
                           <th>Flag</th>
                           
                       
                       </tr>";

            while($row= mysqli_fetch_assoc($result)){  
                       
               echo" <tr>
                      <td> ".$row['employee_id']."</td>
                       <td> ".$row['first_name']."</td>
                       <td> ".$row['middle_name']."</td>
                       <td> ".$row['last_name']."</td>
                       <td> ".$row['DOB']."</td>
                       <td> ".$row['gender']."</td>
                       <td> ".$row['phone_number']."</td>
                       <td> ".$row['email']."</td>
                       <td> ".$row['hourly_wage']."</td>
                       <td> ".$row['salary']."</td>
                       <td> ".$row['street_address']."</td>
                       <td> ".$row['state']."</td>
                       <td> ".$row['zip_code']."</td>
                       <td> ".$row['giftshop_id_fk']."</td>
                       <td> ".$row['event_id_fk']."</td>
                       <td> ".$row['restaurant_id_fk']."</td>
                       <td> ".$row['marketing_id_fk']."</td>
                       <td> ".$row['active_status']."</td>
                       <td> ".$row['attraction_id_fk']."</td>
                       <td> ".$row['maint_id_fk']."</td>
                       <td> ".$row['hire_date']."</td>
                       <td> ".$row['flag']."</td>
                       
                       
                       </tr>";

         }
         
            echo" </table>";
        }
        else{
            echo "There are no results matching your search in the employee table";
        }
     }
    ?>
                        
                   
              
            </div>    
    
</div>
            

            <!--Event Search-->


<div class="events-container">
      
  <?php
    
    if(isset($_POST['submit-search'])){

        if($search_dropdown=="events" or $search_dropdown==""){
             
            echo"<h2> Results in EVENTS</h2>";
            $search= mysqli_real_escape_string($conn, $_POST['search']);
            
            $sql= "SELECT* FROM events WHERE event_name LIKE '%$search%' 
            OR event_id LIKE '%$search%' 
            OR description LIKE '%$search%' 
            OR begin_time LIKE '%$search%' 
            OR end_time LIKE '%$search%' 
            OR rate_per_hour LIKE '%$search%' 
            OR venue_id_fk LIKE '%$search%' 
            OR flag LIKE '%$search%'
            ";
            
            
            
            $result= mysqli_query($conn,$sql);
            $queryResult= mysqli_num_rows($result);
        }
    }
    ?>
    
                <div class="event-container">
                
               
                    
 
    <?php
         if($search_dropdown=="events" or $search_dropdown==""){
    if($queryResult >0){
         
            echo "<table>
                       
                       <tr>
                            
                           <th>Event Id</th>   
                           <th>Event Name</th>
                           <th>Description</th>
                           <th>Begin Time</th>
                           <th>End Time</th>
                           <th>Rate/Hour</th>
                           <th>Venue Id</th>
                           <th>Flag</th>
                        
                       
                       </tr>";
                       while($row= mysqli_fetch_assoc($result)){  
                echo"<tr>
                       <td> ".$row['event_id']."</td>
                       <td> ".$row['event_name']."</td>
                       <td> ".$row['description']."</td>
                       <td> ".$row['begin_time']."</td>
                       <td> ".$row['end_time']."</td>
                       <td> ".$row['rate_per_hour']."</td>
                       <td> ".$row['venue_id_fk']."</td>
                       <td> ".$row['flag']."</td>
                       
                       </tr>";   
         }

          echo"</table>";
        }
        else{
            echo "There are no results matching your search in the events table";
        }
         }
    ?>
                        
                   
              
            </div>    
    
</div>
            
<!--Gift Shop Search-->


<div class="giftshop-container">
      
  <?php
    
    if(isset($_POST['submit-search'])){
        if($search_dropdown=="gift_shop" or $search_dropdown==""){
             
            echo"<h2> Results in GIFT SHOP </h2>";
            $search= mysqli_real_escape_string($conn, $_POST['search']);
            
            $sql= "SELECT* FROM gift_shop WHERE giftshop_id LIKE '%$search%' 
            OR giftshop_name LIKE '%$search%' 
            OR opening_time LIKE '%$search%' 
            OR closing_time LIKE '%$search%' 
            OR location_id_fk LIKE '%$search%'
            OR revenue LIKE '%$search%' 
            OR utilities_cost LIKE '%$search%' 
            OR flag LIKE '%$search%'";
    
            $result= mysqli_query($conn,$sql);
            $queryResult= mysqli_num_rows($result);
    }
    }
    ?>
    
                <div class="gift_shop-container">           
 
    <?php
     if($search_dropdown=="gift_shop" or $search_dropdown==""){
    if($queryResult >0){
        
            echo "<table>
                       
                       <tr>
                         <th>Gift Shop Id</th>
                           <th>Gift Shop Name</th>
                           <th>Opening Time</th>
                           <th>Closing Time</th>
                           <th>Location Id</th>
                           <th>Revenue</th>
                           <th>Utilities Cost</th>
                           <th>Flag</th>
                        
                       
                       </tr>";
                        while($row= mysqli_fetch_assoc($result)){  
               echo" <tr>
                
                      <td> ".$row['giftshop_id']."</td>
                       <td> ".$row['giftshop_name']."</td>
                       <td> ".$row['opening_time']."</td>
                       <td> ".$row['closing_time']."</td>
                       <td> ".$row['location_id_fk']."</td>
                       <td> ".$row['revenue']."</td>
                       <td> ".$row['utilities_cost']."</td>
                       <td> ".$row['flag']."</td>
                       
                </tr>
                       ";

         }
          echo"</table>";
        }
        else{
            echo "There are no results matching your search in the gift shop table";
        }
     }
    ?>
                        
                   
              
            </div>    
    
</div>
            
<!--Location Search-->


<div class="employee-container">
      
  <?php
    
    if(isset($_POST['submit-search'])){
        if($search_dropdown=="location" or $search_dropdown==""){
             
            echo"<h2> Results in LOCATION </h2>";
            $search= mysqli_real_escape_string($conn, $_POST['search']);
            
            $sql= "SELECT* FROM location WHERE location_id LIKE '%$search%' 
            OR location_name LIKE '%$search%' 
            OR location_descripition LIKE '%$search%' 
            ";
        
            $result= mysqli_query($conn,$sql);
            $queryResult= mysqli_num_rows($result);
        }
    }
    ?>
    
                <div class="event-container">
                
               
                    
 
    <?php
     if($search_dropdown=="location" or $search_dropdown==""){
    if($queryResult >0){
        
            echo "<table>
                       
                       <tr>
                       
                       <th>Location Id</th>
                           <th>Location Name</th>
                           <th>Location description</th>
                           <th>Flag</th>
                          
                       </tr>";
                        while($row= mysqli_fetch_assoc($result)){  
                       
                       echo" <tr>
                        
                        <td> ".$row['location_id']."</td>
                       <td> ".$row['location_name']."</td>
                       <td> ".$row['location_descripition']."</td>
                       <td> ".$row['flag']."</td>
                       
                       </tr>";

         }
            echo" </table>";
        }
        else{
            echo "There are no results matching your search in the location table";
        }
     }
    ?>
                        
                   
              
            </div>    
    
</div>
            
            <!--Maintenance Search-->


<div class="maintenanceschedules-container">
      
  <?php
    
    if(isset($_POST['submit-search'])){
        if($search_dropdown=="maintenance_schedule" or $search_dropdown==""){
             
            echo"<h2> Results in MAINTENANCE SCHEDULE </h2>";
            $search= mysqli_real_escape_string($conn, $_POST['search']);
            
            $sql= "SELECT* FROM maintenance_schedules WHERE maintenance_id LIKE '%$search%' 
            OR maint_status LIKE '%$search%' 
            OR date LIKE '%$search%' 
            OR begin_time LIKE '%$search%' 
            OR end_time LIKE '%$search%' 
            OR cost LIKE '%$search%' 
            OR maintenance_details LIKE '%$search%' 
            OR restaurant_id_fk LIKE '%$search%' 
            OR ride_id_fk LIKE '%$search%' 
            OR venue_id_fk LIKE '%$search%' 
            OR giftshop_id_fk LIKE '%$search%' 
            OR flag LIKE '%$search%'
            ";
            
            $result= mysqli_query($conn,$sql);
            $queryResult= mysqli_num_rows($result);
        }
    }
    ?>
    
                <div class="event-container">
                
               
                    
 
    <?php
     if($search_dropdown=="maintenance_schedule" or $search_dropdown==""){
    if($queryResult >0){
         
            echo "<table>
                       
                       <tr>
                           <th>Maintenance Id</th>
                           <th>Maintenance status </th>
                           <th>Date</th>
                           <th>Begin Time</th>
                           <th>End Time</th>
                           <th>Cost</th>
                           <th>Maintenance details</th>
                           <th>Restaurant ID</th>
                           <th>Ride ID</th>
                           <th>Venue ID</th>
                           <th>Gift Shop ID</th>
                           <th>Flag</th>
                        
                       
                       </tr>";
                        while($row= mysqli_fetch_assoc($result)){ 
               echo" <tr>

                      <td> ".$row['maintenance_id']."</td>
                       <td> ".$row['maint_status']."</td>
                       <td> ".$row['date']."</td>
                       <td> ".$row['begin_time']."</td>
                       <td> ".$row['end_time']."</td>
                       <td> ".$row['cost']."</td>
                       <td> ".$row['maintenance_details']."</td>
                       <td> ".$row['restaurant_id_fk']."</td>
                        <td> ".$row['ride_id_fk']."</td>
                        <td> ".$row['venue_id_fk']."</td>
                        <td> ".$row['giftshop_id_fk']."</td>
                        <td> ".$row['flag']."</td>
       
                       </tr> ";

         }
         echo"</table>";
        }
        else{
            echo "There are no results matching your search in the employee table";
        }
     }
    ?>
            </div>    
    
</div>
            
<!--Marketing Search-->


<div class="marketing-container">
      
  <?php
    
    if(isset($_POST['submit-search'])){
        if($search_dropdown=="marketing" or $search_dropdown==""){
             
            echo"<h2> Results in MARKETING </h2>";
            $search= mysqli_real_escape_string($conn, $_POST['search']);
            
            $sql= "SELECT* FROM marketing WHERE marketing_id LIKE '%$search%' 
            OR advertisement_type LIKE '%$search%' 
            OR begin_date LIKE '%$search%' 
            OR end_date LIKE '%$search%' 
            OR cost LIKE '%$search%' 
            OR description LIKE '%$search%' 
            OR flag LIKE '%$search%'
            ";
    
            $result= mysqli_query($conn,$sql);
            $queryResult= mysqli_num_rows($result);
        }
    }
    ?>
    
                <div class="marketing-container">
                
               
                    
 
    <?php
      if($search_dropdown=="marketing" or $search_dropdown==""){
    if($queryResult >0){
        
            echo "<table>
                       
                       <tr>
                           <th>Marketing Id</th>
                           <th>Advertisement type</th>
                           <th>Begin date</th>
                           <th>End date</th>
                           <th>Cost</th>
                           <th>Description</th>
                           <th>Flag</th>
                        
                       
                       </tr>";
                        while($row= mysqli_fetch_assoc($result)){  
                echo"<tr>
                       <td> ".$row['marketing_id']."</td>
                       <td> ".$row['advertisement_type']."</td>
                       <td> ".$row['begin_date']."</td>
                       <td> ".$row['end_date']."</td>
                       <td> ".$row['cost']."</td>
                       <td> ".$row['description']."</td>
                       <td> ".$row['flag']."</td>
                       
                       </tr> ";

         }
         echo"</table>";
        }
        else{
            echo "There are no results matching your search in the marketing table";
        }
      }
    ?>
                        
                   
              
            </div>    
    
</div>
            
            <!--Customer Search-->


<div class="parking-container">
      
  <?php
    
    if(isset($_POST['submit-search'])){
        if($search_dropdown=="parking" or $search_dropdown==""){
             
            echo"<h2> Results in PARKING </h2>";
            $search= mysqli_real_escape_string($conn, $_POST['search']);
            
            $sql= "SELECT* FROM parking WHERE parking_id LIKE '%$search%' 
            OR cost LIKE '%$search%' 
            OR customer_id_fk LIKE '%$search%' 
            OR location_id_fk LIKE '%$search%' 
            OR flag LIKE '%$search%'
            ";
      
            $result= mysqli_query($conn,$sql);
            $queryResult= mysqli_num_rows($result);
        }
    }
    ?>
    
                <div class="event-container">       
                    
 
    <?php
     if($search_dropdown=="parking" or $search_dropdown==""){
    if($queryResult >0){
        
            echo "<table>
                       
                       <tr>
                          <th>Parking Id</th>
                           <th>Cost</th>
                           <th>Customer Id</th>
                           <th>Location Id</th>
                           <th>Flag</th>
                       
                       </tr>";
                        while($row= mysqli_fetch_assoc($result)){  
               echo" <tr>
                     <td> ".$row['parking_id']."</td>
                       <td> ".$row['cost']."</td>
                       <td> ".$row['customer_id_fk']."</td>
                       <td> ".$row['location_id_fk']."</td>
                       <td> ".$row['flag']."</td>
                       
                       </tr>
                        ";

         }
         echo"</table>";
        }
        else{
            echo "There are no results matching your search in the employee datatbase";
        }
     }
    ?>
                        
                   
              
            </div>    
    
</div>
            
            <!--Customer Search-->


<div class="restaurant-container">
      
  <?php
    
    if(isset($_POST['submit-search'])){
        if($search_dropdown=="restaurant" or $search_dropdown==""){
             
            echo"<h2> Results in RESTAURANT </h2>";
            $search= mysqli_real_escape_string($conn, $_POST['search']);
            
            $sql= "SELECT* FROM restaurant WHERE restaurant_id LIKE '%$search%' 
            OR restaurant_name LIKE '%$search%' 
            OR opening_time LIKE '%$search%' 
            OR closing_time LIKE '%$search%' 
            OR location_id_fk LIKE '%$search%' 
            OR revenue LIKE '%$search%' 
            OR utilities_cost LIKE '%$search%' 
            OR flag LIKE '%$search%'
            ";
            
            $result= mysqli_query($conn,$sql);
            $queryResult= mysqli_num_rows($result);
        }
    }
    ?>
    
                <div class="event-container">
                
               
                    
 
    <?php
    if($search_dropdown=="restaurant" or $search_dropdown==""){
    if($queryResult >0){
        
            echo "<table>
                       
                       <tr>
                          <th>Restaurant Id</th>
                           <th>Restaurant Name</th>
                           <th>Opening Time</th>
                           <th>Closing Time</th>
                           <th>Location Id</th>
                           <th>Revenue</th>
                           <th>Utilities Cost</th>
                           <th>Flag</th>
                        
                       
                       </tr>";
                        while($row= mysqli_fetch_assoc($result)){  
               echo" <tr>
                       <td> ".$row['restaurant_id']."</td>
                       <td> ".$row['restaurant_name']."</td>
                       <td> ".$row['opening_time']."</td>
                       <td> ".$row['closing_time']."</td>
                       <td> ".$row['location_id_fk']."</td>
                       <td> ".$row['revenue']."</td>
                       <td> ".$row['utilities_cost']."</td>
                       <td> ".$row['flag']."</td>
                       
                       </tr> ";

         }
         echo"</table>";
        }
        else{
            echo "There are no results matching your search in the restaurant table";
        }
    }
    ?>
                        
                   
              
            </div>    
    
</div>
            
            
            <!--Customer Search-->


<div class="tickets-container">
      
  <?php
    
    if(isset($_POST['submit-search'])){
        if($search_dropdown=="tickets" or $search_dropdown==""){
             
            echo"<h2> Results in TICKETS</h2>";
            $search= mysqli_real_escape_string($conn, $_POST['search']);
            
            $sql= "SELECT* FROM tickets WHERE ticket_id LIKE '%$search%' 
            OR fastpass LIKE '%$search%' 
            OR price LIKE '%$search%' 
            OR date LIKE '%$search%' 
            OR customer_fk_id LIKE '%$search%' 
            OR flag LIKE '%$search%'
            ";
      
            $result= mysqli_query($conn,$sql);
            $queryResult= mysqli_num_rows($result);
        }
    }
    ?>
    
                <div class="event-container">
                

 
    <?php
     if($search_dropdown=="tickets" or $search_dropdown==""){
    if($queryResult >0){
         
            echo "<table>
                       
                       <tr>
                          <th>Ticket Id</th>
                           <th>Fastpass </th>
                           <th>Price </th>
                           <th>Date</th>
                           <th>Customer ID</th>
                           <th>Flag</th>
                        
                       
                       </tr>";
                        while($row= mysqli_fetch_assoc($result)){ 
               echo" <tr>
                      <td> ".$row['ticket_id']."</td>
                       <td> ".$row['fastpass']."</td>
                       <td> ".$row['price']."</td>
                       <td> ".$row['date']."</td>
                       <td> ".$row['customer_fk_id']."</td>
                       <td> ".$row['flag']."</td>
                       
                       
                       </tr> ";

         }
         echo"</table>";
        }
        else{
            echo "There are no results matching your search in the tickets table";
        }
     }
    ?>
                        
                   
              
            </div>    
    
</div>
            
            
            
            <!--Customer Search-->


<div class="venue-container">
      
  <?php
    
    if(isset($_POST['submit-search'])){
        if($search_dropdown=="venue" or $search_dropdown==""){
             
            echo"<h2> Results in VENUE </h2>";
            $search= mysqli_real_escape_string($conn, $_POST['search']);
            
            $sql= "SELECT* FROM venue WHERE venue_id LIKE '%$search%' 
            OR venue_name LIKE '%$search%' 
            OR description LIKE '%$search%' 
            OR location_id_fk LIKE '%$search%' 
            OR flag LIKE '%$search%'
            ";
        
            
            
            $result= mysqli_query($conn,$sql);
            $queryResult= mysqli_num_rows($result);
        }
    }
    ?>
    
                <div class="event-container">
                
               
                    
 
    <?php
    if($search_dropdown=="venue" or $search_dropdown==""){
    if($queryResult >0){
        
            echo "<table>
                       
                       <tr>
                          
                           <th>Venue Id</th>
                           <th>Venue Name</th>
                           <th>Description</th>
                           <th>Location ID</th>
                           <th>Flag</th>
    
             
                       </tr>";
                        while($row= mysqli_fetch_assoc($result)){  
                echo"<tr>
                      <td> ".$row['venue_id']."</td>
                       <td> ".$row['venue_name']."</td>
                       <td> ".$row['description']."</td>
                       <td> ".$row['location_id_fk']."</td>
                       <td> ".$row['flag']."</td>
                       
                       
                       </tr> ";

         }
         echo"</table>";
        }
        else{
            echo "There are no results matching your search in the employee datatbase";
        }
    }
    ?>
                        
                   
              
            </div>    
    
</div>
            
            
</body>
</html>
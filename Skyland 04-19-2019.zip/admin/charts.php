<?php  include('../config.php'); ?>
	<?php include(ROOT_PATH . '/admin/includes/admin_functions.php'); ?>
	<?php include(ROOT_PATH . '/admin/includes/head_section.php'); ?>
	<title>Admin | Dashboard</title>
</head>
<body>
	<div class="header">
		<div class="logo">
			<a href="<?php echo BASE_URL .'admin/dashboard.php' ?>">
				<h1>Themepark - Management</h1>
			</a>
		</div>
		<?php if (isset($_SESSION['employee'])): ?>
			<div class="user-info">
				<span><?php echo $_SESSION['employee']['email'] ?></span> &nbsp; &nbsp; 
				<a href="<?php echo BASE_URL . '/logout.php'; ?>" class="logout-btn">logout</a>
			</div>
		<?php endif ?>
	</div>
	<div class="container dashboard">
		<h1>Welcome</h1>
		<br><br><br>
		<div class="buttons">
			<a href="charts/charts1.php">Amount of General Maint. vs Month (2018)</a>
			<a href="charts/charts2.php">Rides Rain Out vs Month (2018)</a>
			<a href="charts/charts3.php">Amount of rides broken down per month (2018)</a>
			<a href="charts/charts4.php">Amount of Break Down Per Rides</a>
			<a href="charts/charts5.php">Profit Gain vs Profit Loss (2018)</a>
			<a href="charts/charts6.php">Month vs Customers</a>
			<a href="dashboard.php">Back</a>
		</div>
	</div>
</body>
</html>

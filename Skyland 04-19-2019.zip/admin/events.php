<?php require_once('config.php'); ?>
<?php include('events1.php'); ?>

<?php require_once('includes/head_section.php'); ?>

		<!-- navbar -->
<?php include('includes/navbar.php'); ?>

<html>

<div class="register_header">
		<h2>Book for an event</h2>
	</div>

	<form action="events.php" method = "POST">
	
        <?php include('errors.php'); ?>
		
		<div class="register_customer">
			<label>Event Name</label>
			<input type="text" name = "name" placeholder="Ex: Joe's Birthday" required >
		</div>
        <div class="register_customer">
			<label>First Name</label>
			<input type="text" name = "first" placeholder="First Name" required >
		</div>
        		<div class="register_customer">
			<label>Last Name</label>
			<input type="text" name = "last" placeholder="Last Name" required >
		</div>
        		<div class="register_customer">
			<label>Phone Number</label>
			<input type="number" name = "phone" placeholder="Phone Number" required >
		</div>

        <div class="register_customer">
			<label>Email</label>
			<input type="email" name = "email" placeholder="Email" required >
		</div>
        
        <div class="register_customer">
			<label>Event description</label>
			<select name="description" required >
        <option value="birthday">Birthday</option>
        <option value="graduation">Graduation</option>
        <option value="party">Party</option>
        <option value="wedding">Wedding</option>
          
            </select>  
		</div>
    
        
        
		<div class="register_customer">
			<label>Event Date</label>
			<input type="date" name = "date" placeholder="YYYY-MM-DD" required >
		</div>
        
		<div class="register_customer">
			<label>Start Time</label>
			<select name="begin">
        <option value="09:00:00">9:00</option>
        <option value="10:00:00">10:00</option>
        <option value="11:00:00">11:00</option>
        <option value="12:00:00">12:00</option>
        <option value="13:00:00">13:00</option>
        <option value="14:00:00">14:00</option>
        <option value="15:00:00">15:00</option>
        <option value="16:00:00">16:00</option>
        <option value="17:00:00">17:00</option>
        <option value="18:00:00">18:00</option>  
            </select>    
                
		</div>
        
		<div class="register_customer">
			<label>End time</label>
			<select name="end">
       <option value="09:00:00">9:00</option>
        <option value="10:00:00">10:00</option>
        <option value="11:00:00">11:00</option>
        <option value="12:00:00">12:00</option>
        <option value="13:00:00">13:00</option>
        <option value="14:00:00">14:00</option>
        <option value="15:00:00">15:00</option>
        <option value="16:00:00">16:00</option>
        <option value="17:00:00">17:00</option>
        <option value="18:00:00">18:00</option>  
            </select>   
		</div>

        <div class="register_customer">
			<label>Select a Venue</label>
        <?php
                $result = $conn->query("SELECT * FROM venue");
                echo "<select name='venue'>";

                while ($row = $result->fetch_assoc()) {

                            $venueid = $row['venue_id'];
                            $venuename = $row['venue_name']; 
                            echo '<option value="'.$venueid.'">'.$venuename.'</option>';

                }

                echo "</select>";  
            ?>
		</div>

        
        <div class="register_customer">
			<button type="submit" name = "reserveevent" class="btn">Reserve Event</button >
		</div>
		
		
	</form>
</html>
<?php

$update = false;
$id = '';
$name = '';
$rate ='';
$description = '';
$venueid = '';
$begin = '';
$end = '';
$date = '';

$errors = array();
	
if (isset($_POST['btnSave']))
{
        $name = $_POST['name'];
        $description = $_POST['description'];
        $rate = $_POST['rate'];
        $begin = $_POST['begin']; 
        $end= $_POST['end']; 
        $venueid = $_POST['venue'];
        $date = $_POST['date'];
 
	//if any of the input fields were blank, put an error string into the errors array
		if(empty($name)){
			array_push($errors, "Event Name is required.");
		}
		if(empty($rate)){
			array_push($errors, "Rate Per Hour is required.");
		}
		if(empty($description)){
			array_push($errors, "Description is required.");
		}
        if(empty($date)){
			array_push($errors, "Date is required.");
		}
		if(empty($begin)){
			array_push($errors, "Begin Time is required.");
		}
		if(empty($end)){
			array_push($errors, "End Time is required.");
		}
	//if the no errors are in the array
	if(count($errors)==0)
	{
		
		$sql = "INSERT INTO events(event_name, description, rate_per_hour, begin_time, end_time, venue_id_fk, event_date) VALUES ('$name','$description',$rate,'$begin','$end',$venueid,'$date')";
			if (mysqli_query($conn, $sql)) {
				  echo" Event was successfully added.";
			} else {
				  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}
			
			
			$conn->close();
	}
} 


if (isset($_GET['delete']))
{
    $id = $_GET['delete'];
    $update = true;
    if($_SESSION['employee']['manager_status'] == 'Y'){
        $conn->query("UPDATE events SET  flag= 1 WHERE (event_id =$id)") or die($conn->error);
    }else if($_SESSION['employee']['manager_status'] == 'A'){
        $conn->query("UPDATE events SET  flag= 2 WHERE (event_id =$id)") or die($conn->error);
    }
   
    $_SESSION['message'] = "Record has been flagged for deletion!";
    $_SESSION['msg_type']="danger";
    header("location: events.php");
}

if (isset($_GET['edit']))
{
    $id = $_GET['edit'];
    $update = true;
    $result= $conn->query("SELECT * FROM events") or die($conn->error);
    if ($result == true)
    {
        $row=$result->fetch_array();
        $event_id = $row['event_id'];
        $name = $row['event_name'];
        $description = $row['description'];
        $rate = $row['rate_per_hour'];
        $date = $row['event_date'];
        $begin = $row['begin_time']; 
        $end = $row['end_time']; 
        $venueid = $row['venue_id_fk'];
    }
}

if (isset($_POST['btnUpdate']))
{
    $id = $_POST['id'];
        $name = $_POST['name'];
        $description = $_POST['description'];
        $rate = $_POST['rate'];
        $begin = $_POST['begin']; 
        $end = $_POST['end']; 
        $venueid = $_POST['venue'];

    $conn->query("UPDATE events SET  event_name= '$name', description= '$description' ,rate_per_hour =$rate,begin_time = '$begin',end_time='$end', venue_id_fk = $venueid WHERE (event_id ='$id')") or die($conn->error);
    $_SESSION['message'] = "Record has been updated!";
    $_SESSION['msg_type']="warning";
    header("location: events.php");
}

?>

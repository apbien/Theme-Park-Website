<?php 

$errors = array();
if(isset($_POST['reserveevent'])){
	//value for Position (Blank)
		$name = $_POST['name'];
		$description = $_POST['description'];
		$email = $_POST ['email'];
        $date = $_POST['date'];
		$begin = $_POST['begin'];
		$end = $_POST['end'];
        $rate_per_hour='';
        $venueid= $_POST['venue'];
        $first = $_POST['first'];
        $last = $_POST['last'];
        $phone = $_POST['phone'];
    
    if($description== 'birthday' ){
        $rate_per_hour= 67;
    }
     else if ($description== 'graduation' ){
        $rate_per_hour= 70;   
     }
     else if ($description== 'party' ){
        $rate_per_hour= 77;   
     }

     
    

    //This checks if we have a customer with the email entered already exits in the database.
    $get = "SELECT * FROM events WHERE event_date = '$date' AND venue_id_fk = $venueid";
    $result = mysqli_query($conn,$get);
    $queryResults= mysqli_num_rows($result);
     
    if($queryResults>0){
        array_push($errors, "Sorry, that venue is already booked for that specific date.");
    }
        if(count($errors)==0){
            $result2 = $conn->query("SELECT * FROM customer WHERE email = '$email'");
            $numresult = mysqli_num_rows($result2);
            if($numresult > 0){
$reg= "INSERT INTO events(event_name, description, rate_per_hour, begin_time, end_time, venue_id_fk, event_date) VALUES ('$name','$description',$rate_per_hour,'$begin','$end',$venueid,'$date')";
            
    mysqli_query($conn, $reg);

                 $get3 = "SELECT * FROM events WHERE venue_id_fk = '$venueid' AND event_date = '$date'";
                $result3 = $conn->query($get3);
                while($row = $result3->fetch_assoc()){
                    $hello = $row['event_id'];
                    $update = $conn->query("UPDATE customer SET first_name = '$first', last_name = '$last', phone_number = $phone, email='$email', events_id_fk = '$hello' WHERE email = '$email'");
                }
            }else{

$reg= "INSERT INTO events(event_name, description, rate_per_hour, begin_time, end_time, venue_id_fk, event_date) VALUES ('$name','$description',$rate_per_hour,'$begin','$end',$venueid,'$date')";
            
    mysqli_query($conn, $reg);
                $get3 = "SELECT event_id FROM events WHERE venue_id_fk = $venueid AND event_date = '$date'";
                $result3 = $conn->query($get3);
                while($row3 = $result3->fetch_assoc()){
                    $hello = $row3['event_id'];
                    $reg2= $conn->query("INSERT INTO customer(first_name, last_name, email, phone_number, events_id_fk) VALUES ('$first','$last','$email',$phone,$hello)");

                }
        }
        ?> <h1>Your event was successfully booked!</h1> <?php
        }
        
  


 
}

?>

<div>
</div>
<!--<a href="index.php">Back to home page</a>-->
<?php

$update = false;
$id = '';
$venue_id = '';
$venue_name ='';
$description = '';
$location_id_fk = '';

$errors = array();
	
if (isset($_POST['btnSave']))
{
	$venue_name = $_POST['venue_name'];
    $description = $_POST['description'];
    $location_id_fk = $_POST['location_id_fk']; 
 
	//if any of the input fields were blank, put an error string into the errors array
		if(empty($venue_name)){
			array_push($errors, "Venue Name is required.");
		}
		if(empty($location_id_fk)){
			array_push($errors, "Venue Location is required.");
		}
		if(empty($description)){
			array_push($errors, "Description is required.");
		}
	//if the no errors are in the array
	if(count($errors)==0)
	{
		
		$sql = "INSERT INTO venue (venue_name, description, location_id_fk) VALUES ('$venue_name','$description','$location_id_fk')";
			if (mysqli_query($conn, $sql)) {
				  echo" Venue was successfully added.";
			} else {
				  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}
			
			
			$conn->close();
	}
} 

if (isset($_GET['delete']))
{
    $id = $_GET['delete'];
    $update = true;
    if($_SESSION['employee']['manager_status'] == 'Y'){
        $conn->query("UPDATE venue SET  flag= 1 WHERE (venue_id =$id)") or die($conn->error);
    }else if($_SESSION['employee']['manager_status'] == 'A'){
        $conn->query("UPDATE venue SET  flag= 2 WHERE (venue_id =$id)") or die($conn->error);
    }
   
    $_SESSION['message'] = "Record has been flagged for deletion!";
    $_SESSION['msg_type']="danger";
    header("location: venue.php");
}

if (isset($_GET['edit']))
{
    $id = $_GET['edit'];
    $update = true;
    $result= $conn->query("SELECT * FROM venue WHERE venue_id=$id") or die($conn->error);
    if ($result == true)
    {
        $row=$result->fetch_array();
        $venue_id = $row['venue_id'];
        $venue_name = $row['venue_name'];
        $description = $row['description'];
        $location_id_fk = $row['location_id_fk'];
    }
}

if (isset($_POST['btnUpdate']))
{
    $id = $_POST['id'];
    $venue_name = $_POST['venue_name'];
    $description = $_POST['description'];
    $location_id_fk = $_POST['location_id_fk'];

    $conn->query("UPDATE venue SET  venue_name= '$venue_name', description= '$description' ,location_id_fk ='$location_id_fk' WHERE (venue_id ='$id')") or die($conn->error);
    $_SESSION['message'] = "Record has been updated!";
    $_SESSION['msg_type']="warning";
    header("location: venue.php");
}

?>

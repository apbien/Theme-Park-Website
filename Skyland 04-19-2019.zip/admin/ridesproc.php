<?php

$update = false;
$ride_maint = false;
$id = '';
$ride_id = '';
$name_id ='';
$description = "";
$ride_requirement = '';
$active_status = '';
$date_built = '';
$location_id_fk = '';
$errors = array();
	
if (isset($_POST['btnSave']))
{
    $name_id = $_POST['name'];
    $description = $_POST['description'];
    $ride_requirement = $_POST['ride_requirement'];
    $active_status = $_POST['active_status']; 
    $date_built= $_POST['date_built']; 
    $location_id_fk  = $_POST['location_id_fk']; 
	//if any of the input fields were blank, put an error string into the errors array
		if(empty($name_id)){
			array_push($errors, "Ride Name is required.");
		}
		if(empty($ride_requirement)){
			array_push($errors, "Ride Requirement is required.");
		}
		if(empty($active_status)){
			array_push($errors, "Active Status is required.");
		}
		if(empty($date_built)){
			array_push($errors, "Date Built is required.");
		}
		if(empty($location_id_fk)){
			array_push($errors, "Location is required.");
		}
	//if the no errors are in the array
	if(count($errors)==0)
	{
		
		$sql = "INSERT INTO attraction (name, description, ride_requirement, active_status, date_built, location_id_fk) VALUES ('$name_id','$description','$ride_requirement','$active_status','$date_built','$location_id_fk')";
			if (mysqli_query($conn, $sql)) {
				   $_SESSION['message'] = "Attraction was successfully added! To have it show up, make sure it goes through a maintenance first.";
			} else {
				  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}
			
			
			$conn->close();
	}
} 

if (isset($_GET['delete']))
{
    $id = $_GET['delete'];
    $update = true;
    if($_SESSION['employee']['manager_status'] == 'Y'){
        $conn->query("UPDATE attraction SET  flag= 1 WHERE (ride_id =$id)") or die($conn->error);
    }else if($_SESSION['employee']['manager_status'] == 'A'){
        $conn->query("UPDATE attraction SET  flag= 2 WHERE (ride_id =$id)") or die($conn->error);
    }
   
    $_SESSION['message'] = "Record has been flagged for deletion!";
    $_SESSION['msg_type']="danger";
    header("location: Rides.php");
}

if (isset($_GET['edit']))
{
    $id = $_GET['edit'];
    $update = true;
   $result= $conn->query("SELECT * FROM attraction WHERE ride_id=$id") or die($conn->error);
    if ($result == true)
    {
        $row=$result->fetch_array();
        $ride_id = $row['ride_id'];
        $name_id = $row['name'];
        $description = $row['description'];
        $ride_requirement = $row['ride_requirement'];
        $active_status = $row['active_status']; 
        $date_built= $row['date_built']; 
        $location_id_fk  = $row['location_id_fk']; 
        
    }
}

if (isset($_POST['btnUpdate']))
{
    $id = $_POST['id'];
    $name_id = $_POST['name'];
    $description = $_POST['description'];
    $ride_requirement = $_POST['ride_requirement'];
    $active_status = $_POST['active_status']; 
    $date_built= $_POST['date_built']; 
    $location_id_fk  = $_POST['location_id_fk']; 
    $conn->query("UPDATE attraction SET  name= '$name_id', description= '$description' ,ride_requirement ='$ride_requirement',active_status = '$active_status',date_built='$date_built',location_id_fk='$location_id_fk' WHERE (ride_id ='$id')") or die($conn->error);
    $_SESSION['message'] = "Record has been updated!";
    $_SESSION['msg_type']="warning";
    header("location: Rides.php");
}


?>

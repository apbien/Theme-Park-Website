<?php  include('../config.php'); ?>
<?php  include(ROOT_PATH . '/admin/includes/admin_functions.php'); ?>
<?php 
	// Get all admin users from DB
	$admins = getUsers();
	$roles = ['Admin','Restaurant_Employee','GiftShop_Employee','Marketing_Employee','Attraction_Employee','Maintenance_Employee','Event_Employee'];	
	$status = ['Y', 'N'];				
?>
<?php include(ROOT_PATH . '/admin/includes/head_section.php'); ?>
	<title>Admin | Manage users</title>


<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>

<body>

  <?php require_once 'UserProc.php'; ?>
  <?php 
  if(isset($_SESSION['message'])):
  ?> 

<div class="alert alert-<?=$_SESSION['msg_type']?>">
  <?php 
  echo $_SESSION['message'];
  unset($_SESSION['message']);
  ?>
</div>
  <?php endif?>


	<!-- admin navbar -->
	<?php include(ROOT_PATH . '/admin/includes/navbar.php') ?>
	<div class="container content">
		<!-- Left side menu -->
		<?php include(ROOT_PATH . '/admin/includes/menu.php') ?>
		<!-- Middle form - to create and edit  -->
		<div class="action">
			<h1 class="page-title">Edit Existing Users</h1>
			

				<?php
					//CHANGE: for the line of code under this one, change (WHERE employee_id = 1) to the current logged in user
				

					if (isset($_SESSION['email'])) {
  						$email = $_SESSION['email'];
					}
					$sql = "SELECT * FROM employee WHERE email= '$email'";
					$result = $conn-> query($sql);
					while ($row = mysqli_fetch_assoc($result)){
	
						
						$first_name = $row['first_name'];
						$middle_name = $row['middle_name'];
						$last_name = $row['last_name'];
						$DOB = $row['DOB'];
						$gender = $row['gender'];
						$hours = $row['hours'];
						$hourly_wage = $row['hourly_wage'];
						$phone_number=$row['phone_number']; 
             			$email=$row['email'];  
             			$street_address=$row['street_address']; 
             			$state=$row['state']; 
             			$zip_code=$row['zip_code']; 
             			$hire_date=$row['hire_date']; 
             			$manager_status=$row['manager_status']; 
             			$active_status=$row['active_status']; 

						

				}
				?>



			<form method="$_POST" action="Users.php" >

				<!-- validation errors for the form -->
				<?php include(ROOT_PATH . '/includes/errors.php') ?>

				<!-- if editing user, the id is required to identify that user (button is hidden away from user, but is sent to the server) -->
				<?php if ($isEditingUser === true): ?>
					<input type="hidden" name="admin_id" value="<?php echo $admin_id; ?>">
				<?php endif ?>

				<div class="form-group">
					<label>First Name:</label>				
						<input type="text" name="first_name" value="<?php echo $first_name ?>" placeholder="First Name">
				</div>

				<div class="form-group">
					<label>Middle Name:</label>				
						<input type="text" name="middle_name" value="<?php echo $middle_name ?>" placeholder="Middle Name">
				</div>

				<div class="form-group">
					<label >Last Name:</label>				
						<input type="text" name="last_name" value="<?php echo $last_name ?>" placeholder="Last Name">
				</div>

				<div class="form-group">
					<label>Date of Birth:</label>
						<br>									
					<input type="date" name="DOB" value="<?php echo $DOB ?>" placeholder="DOB">
				</div>

				<div class="form-group">
					<label>Gender:</label>				
						<select class="form-control" placeholder="Gender" value="<?php echo $gender; ?>" name="gender">
							<option value = "M" >Male</option>
							<option value = "F" >Female</option>
							<option value = "O" >Other</option>
						</select>
					
				</div>

				<div class="form-group">
					<label>Hours:</label>		
						<br>								
						<input type="number" name="hours" value="<?php echo $hours ?>" placeholder="Hours">
				</div>

				<div class="form-group">
					<label>Hourly Wage:</label>
						<br>	
						<input type="number" name="hourly_wage" value="<?php echo $hourly_wage ?>" placeholder="Hourly Wage">
				</div>

				<div class="form-group">
					<label>Salary:</label>
						<br>	
						<input type="number" name="salary" value="<?php echo $salary ?>" placeholder="Salary">
				</div>

				<div class="form-group">
					<label>Phone Number:</label>
					<br>	
						<input type="number" name="phone_number" value="<?php echo $phone_number ?>" placeholder="Phone Number">
				</div>

				<div class="form-group">
					<label>Email:</label>
						<br>						
						<input type="email" name="email" value="<?php echo $email ?>" placeholder="Email">
				</div>


				<div class="form-group">
					<label>Street Address:</label>
						<br>											
						<input type="text" name="street_address" value="<?php echo $street_address ?>" placeholder="Street Address">
				</div>

				<div class="form-group">
					<label>State:</label>	
						<br>						
					<input type="text" name="state" value="<?php echo $state ?>" placeholder="State">
				</div>
				
				<div class="form-group">
					<label>Zip Code:</label>	
						<br>						
					<input type="number" name="zip_code" value="<?php echo $zip_code ?>" placeholder="Zip Code">
				</div>
				
				<div class="form-group">
					<label class="control-label col-sm-2">Hire Date:</label>
						<br>									
					<input type="date" name="hire_date" value="<?php echo $hire_date ?>" placeholder="Hire Date">
				</div>

				<div class="form-group">
					<label>Active Status:</label>	
						<br>	
				
					<select class="form-control" placeholder="Active Status" value="<?php echo $active_status; ?>" name="active_status">
						<option value = "Y" >Active</option>
						<option value = "N" >Inactive</option>
					</select>
				</div>	

				<label>Manager Status:</label>	
						<br>	
				
				<select class="form-control" placeholder="Manager Status" value="<?php echo $manager_status; ?>" name="manager_status">
          			<option value = "Y" >Manager</option>
          			<option value = "N" >Not a Manager</option>
          		</select>


				<button type="submit" class="btn btn-info" name='btnUpdate'>UPDATE</button>

				<!-- if editing user, display the update button instead of create button 
				<?php if ($isEditingUser === true): ?> 
					<button type="submit" class="btn" formaction="users.php">UPDATE</button>
				<?php endif ?>-->
			</form> 

		</div>
		<!-- // Middle form - to create and edit -->
	</div>
	if
</body>
</html>
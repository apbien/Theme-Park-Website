<?php

$update = false;
$id = '';
$giftshop_id = '';
$giftshop_name ='';
$merchandise_list = '';
$utilities_cost = '';
$revenue = '';
$opening_time = '';
$closing_time = '';
$location_id_fk = '';
$errors = array();


if (isset($_POST['btnSave']))
{
    $giftshop_name = $_POST['giftshop_name'];
    $merchandise_list = $_POST['merchandise_list'];
    $utilities_cost = $_POST['utilities_cost'];
    $revenue = $_POST['revenue']; 
    $opening_time= $_POST['opening_time'];
    $closing_time  = $_POST['closing_time'];  
    $location_id_fk  = $_POST['location_id_fk'];  

        //if any of the input fields were blank, put an error string into the errors array
        if(empty($giftshop_name)){
            array_push($errors, "Gift Shop Name is required.");
        }
        if(empty($merchandise_list)){
            array_push($errors, "List of Items is required.");
        }
        if(empty($utilities_cost)){
            array_push($errors, "Utilities Cost is required.");
        }
        if(empty($revenue)){
            array_push($errors, "Revenue is required.");
        }
        if(empty($opening_time)){
            array_push($errors, "Opening Time is required.");
        }
        if(empty($closing_time)){
            array_push($errors, "Closing Time is required.");
        }
        if(empty($location_id_fk)){
            array_push($errors, "Location is required.");
        }
        if(count($errors)==0){

            $sql = "INSERT INTO gift_shop(giftshop_name, merchandise_list, utilities_cost, revenue, opening_time, closing_time) VALUES ('$giftshop_name',$utilities_cost,$revenue,'$opening_time','$closing_time','$location_id_fk')";

            if (mysqli_query($conn, $sql)) {
                $_SESSION['message'] = "Giftshop was successfully added. Add a maintenance to it for it to show up.";
            } else {
                     echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }
            
                $conn->close();
        }
} 

if (isset($_GET['delete']))
{
    $id = $_GET['delete'];
    $update = true;
    if($_SESSION['employee']['manager_status'] == 'Y'){
        $conn->query("UPDATE gift_shop SET  flag= 1 WHERE (giftshop_id =$id)") or die($conn->error);
    }else if($_SESSION['employee']['manager_status'] == 'A'){
        $conn->query("UPDATE gift_shop SET  flag= 2 WHERE (giftshop_id =$id)") or die($conn->error);
    }
   
    $_SESSION['message'] = "Record has been flagged for deletion!";
    $_SESSION['msg_type']="danger";
    header("location: Shops.php");
}

if (isset($_GET['edit']))
{
    $id = $_GET['edit'];
    $update = true;
    $result= $conn->query("SELECT * FROM gift_shop WHERE giftshop_id=$id") or die($conn->error);
    if ($result == true)
    {
        $row=$result->fetch_array();
        $giftshop_name = $row['giftshop_name'];
        $merchandise_list = $row['merchandise_list'];
        $utilities_cost = $row['utilities_cost'];
        $revenue = $row['revenue']; 
        $opening_time= $row['opening_time']; 
        $closing_time  = $row['closing_time']; 
        $location_id_fk  = $row['location_id_fk']; 
        
    }
}

if (isset($_POST['btnUpdate']))
{
    $id = $_POST['id'];
    $giftshop_name = $_POST['giftshop_name'];
    $merchandise_list = $_POST['merchandise_list'];
    $utilities_cost = $_POST['utilities_cost'];
    $revenue = $_POST['revenue']; 
    $opening_time = $_POST['opening_time']; 
    $closing_time = $_POST['closing_time']; 
    $location_id_fk = $_POST['location_id_fk']; 
    $conn->query("UPDATE gift_shop SET  giftshop_name= '$giftshop_name', merchandise_list= '$merchandise_list' ,utilities_cost = $utilities_cost,revenue = $revenue,opening_time='$opening_time',closing_time= '$closing_time', location_id_fk='$location_id_fk' WHERE giftshop_id =$id") or die($conn->error);
    $_SESSION['message'] = "Record has been updated!";
    $_SESSION['msg_type']="warning";
    header("location: Shops.php");
}

?>
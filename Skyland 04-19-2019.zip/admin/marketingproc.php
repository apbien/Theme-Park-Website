<?php

$update = false;
$id = '';
$marketing_id = '';
$cost ='';
$description = '';
$type = '';
$begin = '';
$end = '';

$errors = array();
	
if (isset($_POST['btnSave']))
{
	$cost = $_POST['cost'];
    $description = $_POST['description'];
    $type = $_POST['type'];
    $begin = $_POST['begin']; 
    $end= $_POST['end']; 
 
	//if any of the input fields were blank, put an error string into the errors array
		if(empty($cost)){
			array_push($errors, "Cost is required.");
		}
		if(empty($type)){
			array_push($errors, "Marketing Type is required.");
		}
		if(empty($description)){
			array_push($errors, "Description is required.");
		}
		if(empty($begin)){
			array_push($errors, "Begin Date is required.");
		}
		if(empty($end)){
			array_push($errors, "End Date is required.");
		}
	//if the no errors are in the array
	if(count($errors)==0)
	{
		
		$sql = "INSERT INTO marketing (cost, description, advertisement_type, begin_date, end_date) VALUES ('$cost','$description','$type','$begin','$end')";
			if (mysqli_query($conn, $sql)) {
				  echo" Marketing was successfully added.";
			} else {
				  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}
			
			
			$conn->close();
	}
} 


if (isset($_GET['delete']))
{
    $id = $_GET['delete'];
    $update = true;
    if($_SESSION['employee']['manager_status'] == 'Y'){
        $conn->query("UPDATE marketing SET  flag= 1 WHERE (marketing_id =$id)") or die($conn->error);
    }else if($_SESSION['employee']['manager_status'] == 'A'){
        $conn->query("UPDATE marketing SET  flag= 2 WHERE (marketing_id =$id)") or die($conn->error);
    }
   
    $_SESSION['message'] = "Record has been flagged for deletion!";
    $_SESSION['msg_type']="danger";
    header("location: marketing.php");
}

if (isset($_GET['edit']))
{
    $id = $_GET['edit'];
    $update = true;
   $result= $conn->query("SELECT * FROM marketing WHERE marketing_id=$id") or die($conn->error);
    if ($result == true)
    {
        $row=$result->fetch_array();
        $marketing_id = $row['marketing_id'];
        $cost = $row['cost'];
        $description = $row['description'];
        $type = $row['advertisement_type'];
        $begin = $row['begin_date']; 
        $end = $row['end_date']; 
        
    }
}

if (isset($_POST['btnUpdate']))
{
    $id = $_POST['id'];
    $cost = $_POST['cost'];
    $description = $_POST['description'];
    $type = $_POST['type'];
    $begin = $_POST['begin']; 
    $end = $_POST['end']; 

    $conn->query("UPDATE marketing SET  cost= '$cost', description= '$description' ,advertisement_type ='$type',begin_date = '$begin',end_date='$end' WHERE (marketing_id ='$id')") or die($conn->error);
    $_SESSION['message'] = "Record has been updated!";
    $_SESSION['msg_type']="warning";
    header("location: marketing.php");
}

?>

<?php  include('../config.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Maintenance</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
  <?php require_once 'maint_proc_gift.php'; ?>
  <?php 
  if(isset($_SESSION['message'])):
  ?>

<div class="alert alert-<?=$_SESSION['msg_type']?>">
  <?php 
  echo $_SESSION['message'];
  unset($_SESSION['message']);
  ?>
</div>
  <?php endif?>

  <?php
  $result = $conn-> query("SELECT maintenance_schedules.*,gift_shop.giftshop_name FROM maintenance_schedules JOIN gift_shop ON maintenance_schedules.giftshop_id_fk = gift_shop.giftshop_id");
  $result2 = $conn-> query("SELECT gift_shop.giftshop_name FROM gift_shop");

  ?>
<div class="container">
  <h1 class="vertical-center" style="text-align:center;background-color:#000000;color: aliceblue;min-height:15vh;">Gift Shop Maintenance Data Management Form</h1>      
  <br>
<div>

  <form id="maintForm" method="post" class="form-horizontal" action="maint_gift.php"> <div>
  <input type="hidden" name="id" value= "<?php echo $id;?>">
  
  
    <nav class="navbar-form" style="background:whitesmoke">
        <div class="nav navbar-nav navbar-right">
          <?php 
          if ($update == true):
          ?>
          <button type="submit" class="btn btn-info" name= "btnUpdate">Update</button>
          <?php else: ?>
          <button type="submit" class="btn btn-primary" name= "btnSave">Save</button>
          <?php endif; ?>
        </div> <br> <br>
    </nav>
  </div>

	<?php include('errors.php'); ?>
	
	 <div class="form-group">
      <label class="control-label col-sm-2">Date:</label>
      <div class="col-sm-5">
        <input type="date" class="form-control" placeholder="Enter Date" value="<?php echo $date; ?>" name="date">
      </div>
    </div>
	
    <div class="form-group">
      <label class="control-label col-sm-2">Begin Time:</label>
      <div class="col-sm-5">
        <input type="time" class="form-control" placeholder="Enter Begin Time" value="<?php echo $begin; ?>" name="begin">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2">End Time:</label>
      <div class="col-sm-5">
        <input type="time" class="form-control" placeholder="Enter End Time" value="<?php echo $end; ?>" name="end" >
      </div>
    </div>
	
	 <div class="form-group">
      <label class="control-label col-sm-2">Cost:</label>
      <div class="col-sm-5">
        <input type="number" class="form-control" placeholder="Enter Cost (Leave blank for N/A)" value="<?php echo $cost; ?>" name="cost" >
      </div>
    </div>
	
	<div class="form-group">
      <label class="control-label col-sm-2">Maintenance Status</label>
      <div class="col-sm-5">
        <select class="form-control" placeholder = "Choose Maintenance Status" id="status" name="status">
			<option value="<?php echo $status; ?>"><?php echo $status; ?></option>
			<option value="Assigned">Assigned</option>
			<option value="Started">Started</option>
			<option value="Recorded">Recorded</option>
			<option value="Finished">Finished</option>
		</select>
      </div>
    </div>

	<div class="form-group">
      <label class="control-label col-sm-2">Maintenance Details</label>
      <div class="col-sm-5">
        <select class="form-control" placeholder = "Choose Maintenance Details" id="status" name="details">
			<option value="<?php echo $details; ?>"><?php echo $details; ?></option>
			<option value="in-progress">In-Progress</option>
			<option value="general_maint">General Maintenance</option>
			<option value="broken_down">Broken Down</option>
		</select>
      </div>
    </div>
	
	

	<div class="form-group">
      <label class="control-label col-sm-2">Location of Maintenance</label>
      <div class="col-sm-5">
        <select class="form-control" placeholder = "Choose Location" id="location" name="location">
		<option value="<?php echo $location; ?>"><?php echo $location; ?></option>
		<?php while($row = $result2->fetch_assoc()): ?>
		<option value="<?php echo $row['giftshop_name']; ?>"><?php echo $row['giftshop_name']; ?></option>
		<?php endwhile; ?>
		</select>
      </div>
    </div>



  </form>

  <form>
    <button type="submit" class="btn btn-success" formaction="Shops.php">Back</button>
    <button type="submit" class="btn btn-dark" formaction="dashboard.php">Return to Management Page</button>
  </form>

  <script>
    function myFunction() {
      document.getElementById("myForm").reset();
    }
</script>

  <br>
  <br>
  <br>
 
  <div class="row justify-content-center">
    <table class="table table-striped table-bordered table-hover table-condensed">
      <thead>
        <tr>
          <th>ID</th>
          <th>Date</th>
          <th>Begin Time</th>
          <th>End Time</th>
	        <th>Cost</th>
          <th>Maintenance Status</th>
          <th>Maintenance Details</th>
		  <th>Location</th>
          <th colspan="2">Action</th>
        </tr>
      </thead>
    <?php while($row = $result->fetch_assoc()): ?>
	
        <tr>
          <td><?php echo $row['maintenance_id']; ?></td>
          <td><?php echo $row['date']; ?></td>
          <td><?php echo $row['begin_time']; ?></td>
          <td><?php echo $row['end_time']; ?></td>
	        <td><?php echo $row['cost']; ?></td>
          <td><?php echo $row['maint_status']; ?></td>
          <td><?php echo $row['maintenance_details']; ?></td>
		   <td><?php echo $row['giftshop_name']; ?></td>

          <td>
            <a href="maint_gift.php?edit=<?php echo $row['maintenance_id'];?>"
             class="btn btn-info">Edit</a>
            <a href="maint_proc_gift.php?delete=<?php echo $row['maintenance_id'];?>"
             class="btn btn-danger">Delete</a>          
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>
  </div>
</div>

</body>
</html>
<?php  include('../config.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Marketing</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
  <?php require_once 'marketingproc.php'; ?>
  <?php 
  if(isset($_SESSION['message'])):
  ?>

<div class="alert alert-<?=$_SESSION['msg_type']?>">
  <?php 
  echo $_SESSION['message'];
  unset($_SESSION['message']);
  ?>
</div>
  <?php endif?>

  <?php
  $result = $conn-> query("SELECT * FROM marketing");
  ?>
<div class="container">
  <h1 class="vertical-center" style="text-align:center;background-color:#000000;color: aliceblue;min-height:15vh;">Marketing Data Management Form</h1>      
  <br>
<div>

  <form id="marketingForm" method="post" class="form-horizontal" action="marketing.php"> <div>
  <input type="hidden" name="id" value= "<?php echo $id;?>">
  
  
    <nav class="navbar-form" style="background:whitesmoke">
        <div class="nav navbar-nav navbar-right">
          <?php 
          if ($update == true):
          ?>
          <button type="submit" class="btn btn-info" name= "btnUpdate">Update</button>
          <?php else: ?>
          <button type="submit" class="btn btn-primary" name= "btnSave">Save</button>
          <?php endif; ?>
        </div> <br> <br>
    </nav>
  </div>

  <?php include('errors.php'); ?>
    <div class="form-group">
      <label class="control-label col-sm-2">Cost:</label>
      <div class="col-sm-5">
        <input type="text" class="form-control" placeholder="Enter Advertisement Cost" value="<?php echo $cost; ?>" name="cost">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2">Description:</label>
      <div class="col-sm-5">
        <input type="text" class="form-control" placeholder="Enter Advertisement Description" value="<?php echo $description; ?>" name="description" >
      </div>
    </div>
  
    <div class="form-group">
      <label class="control-label col-sm-2">Marketing Type</label>
      <div class="col-sm-5">
        <input type="text" class="form-control" placeholder="Enter Advertisement Type " value="<?php echo $type; ?>" name="type">
      </div>
    </div>
 
    <div class="form-group">
      <label class="control-label col-sm-2">Begin Date:</label>
      <div class="col-sm-5">
        <input type="date" class="form-control" placeholder="Enter Begin Date" value="<?php echo $begin; ?>" name="begin">
      </div>
    </div>
  
  <div class="form-group">
      <label class="control-label col-sm-2">End Date:</label>
      <div class="col-sm-5">
        <input type="date" class="form-control" placeholder="Enter End Date" value="<?php echo $end; ?>" name="end">
      </div>
    </div>
    

  </form>

    <form>
    <button type="submit" class="btn btn-dark" formaction="dashboard.php">Return to Management Page</button>
  </form>

  <script>
    function myFunction() {
      document.getElementById("myForm").reset();
    }
</script>

  <br>
  <br>
  <br>
 
  <div class="row justify-content-center">
    <table class="table table-striped table-bordered table-hover table-condensed">
      <thead>
        <tr>
          <th>ID</th>
          <th>Cost</th>
          <th>Description</th>
          <th>Advertisement Type</th>
          <th>Begin Date</th>
          <th>End Date</th>
          <th colspan="2">Action</th>
        </tr>
      </thead>
    <?php while($row = $result->fetch_assoc()): ?>
    <?php if($_SESSION['employee']['manager_status'] == "Y" && $row['flag'] == 0): ?>
              <tr>
          <td><?php echo $row['marketing_id']; ?></td>
          <td><?php echo $row['cost']; ?></td>
          <td><?php echo $row['description']; ?></td>
          <td><?php echo $row['advertisement_type']; ?></td>
        <td><?php echo $row['begin_date']; ?></td>
          <td><?php echo $row['end_date']; ?></td>

          <td>
            <a href="marketing.php?edit=<?php echo $row['marketing_id'];?>"
             class="btn btn-info">Edit</a>
            <a href="marketing.php?delete=<?php echo $row['marketing_id'];?>"
             class="btn btn-danger">Delete</a>          
          </td>
        </tr>
    <?php endif ?>
    <?php if($_SESSION['employee']['manager_status'] == "A" && $row['flag'] < 2): ?>
              <tr>
          <td><?php echo $row['marketing_id']; ?></td>
          <td><?php echo $row['cost']; ?></td>
          <td><?php echo $row['description']; ?></td>
          <td><?php echo $row['advertisement_type']; ?></td>
        <td><?php echo $row['begin_date']; ?></td>
          <td><?php echo $row['end_date']; ?></td>

          <td>
            <a href="marketing.php?edit=<?php echo $row['marketing_id'];?>"
             class="btn btn-info">Edit</a>
            <a href="marketing.php?delete=<?php echo $row['marketing_id'];?>"
             class="btn btn-danger">Delete</a>          
          </td>
        </tr>
    <?php endif ?>

      <?php endwhile; ?>
    </table>
  </div>
  </div>
</div>

</body>
</html>
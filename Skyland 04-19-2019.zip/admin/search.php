<?php  include('../config.php'); ?>

<!DOCTYPE html>
<html>
    <head>
        
        <title> LOOK UP TABLE </title>
        <style> 
            table,tr, th,td{
                border: 1px solid black;
            }
        </style>
        
        <link rel="stylesheet" type="text/css" href="stylesheets/style_search.css"/>
         
    </head>
        <body>
            
            
            <form action=" search1.php" method="POST"> 
                <input type= "text" name ="search" placeholder= "Search">
                 <select name="search_dropdown">
                    <option value="">Select a field</option>
                    <option value="attraction">Attraction</option>
                    <option value="customer">Customer</option>
                    <option value="employee">Employee</option>
                    <option value="events">Events</option>
                    <option value="gift_shop">Gift Shop</option>
                    <option value="location"> Location</option>
                    <option value="maintenance_schedule">Maintenance Schedule</option>
                    <option value="marketing">Marketing</option>
                    <option value="parking">Parking</option>
                    <option value="restaurant">Restaurant</option>
                    <option value="tickets">Tickets</option>
                    <option value="venue">Venue</option>
           
            </select>
             <select name="filter">
                    <option value="">Filter Search</option>
                    <option value="contains">Contains</option>
                    <option value="only_has">Only has</option>
                    
                   
           
            </select>
                <button type="submit" name="submit-search">Search</button>

                <button type="submit" class="btn btn-success" formaction="dashboard.php">Return to Dashboard</button>
            </form>
            
            <h1>LOOK UP TABLE</h1>
            
            
             <!--Section for Attraction-->
              
            <h2>All Attraction data</h2>
            
            <div class="attraction-container">
                
               
                    <table>
                       
                       <tr>
                           
                           <th>Ride Id</th>
                           <th>Ride Name</th>
                           <th>Ride Requirements</th>
                           <th>Date Built</th>
                           <th>Descrition</th>
                           <th>Active Status</th>
                           <th> Location Id</th>
                           <th>Ticket Id</th>
                            <th>Flag</th>

        
                       </tr>
                       
                <?php
                
                $sql= "SELECT* FROM attraction";
                $results= mysqli_query($conn,$sql);
                $queryResults= mysqli_num_rows($results);
                
                if($queryResults>0){
                    while($row = mysqli_fetch_assoc($results)){
                      echo "<tr>
                       <td> ".$row['ride_id']."</td>
                       <td> ".$row['name']."</td>
                       <td> ".$row['ride_requirement']."</td>
                       <td> ".$row['date_built']."</td>
                       <td> ".$row['description']."</td>
                       <td> ".$row['active_status']."</td>
                       <td> ".$row['location_id_fk']."</td>
                        <td> ".$row['ticket_id_fk']."</td>
                        <td> ".$row['flag']."</td>
                       
                       </tr>";
                          
                    }
                }
                
               ?>

                </table>
              
            </div>
            
            
              <!--Section for Customer-->
            
            <h2>All Customers data </h2>
            
            <div class="customer-container">
                
               
                <table>
                       
                    <tr>
                            <th>Customer Id</th>
                            <th>First Name</th>
                           <th>Last Name</th>
                           <th>DOB</th>
                           <th>Phone Number</th>
                           <th>Email</th>
                           <th>Events Id</th>
                           <th>Flag</th>
                           
                    </tr>
                       
                <?php
                
                $sql= "SELECT* FROM customer";
                $results= mysqli_query($conn,$sql);
                $queryResults= mysqli_num_rows($results);
                
                if($queryResults>0){
                    while($row = mysqli_fetch_assoc($results)){
                      echo "
                      <tr>
                       <td> ".$row['customer_id']."</td>
                       <td> ".$row['first_name']."</td>
                       <td> ".$row['last_name']."</td>
                       <td> ".$row['DOB']."</td>
                       <td> ".$row['phone_number']."</td>
                       <td> ".$row['email']."</td>
                       <td> ".$row['flag']."</td>
                       
                       </tr>";
                          
                    }
                }
                
               ?>

                </table>
              
            </div>
            
            <!--Section for employees-->
            
            <h2>All Employees data </h2>
            
            <div class="employee-container">
                
               
                    <table>
                       
                      <tr>
                           <th>Employee Id</th>
                           <th>First Name</th>
                           <th>Middle Name</th>
                           
                           <th>Last Name</th>
                           <th>DOB</th>
                           <th>Gender</th>
                           
                           <th>Phone Number</th>
                           <th>Email</th>
                           <th>Hourly wage</th>
                           
                           <th>Salary</th>
                           <th>Street Adress</th>
                           <th>State</th>
                           
                           <th>Zip Code</th>
                           
                           <th>Gift Shop ID</th>
                           <th>Event ID</th>
                           <th>Restaurant ID</th>
                           <th>Marketing ID</th>
                           <th>Active Status ID</th>
                           <th>Attraction ID</th>
                           <th>Maintenance ID</th>
                           <th>Hire Date</th>
                           <th>Flag</th>
                           
                       
                       </tr>
                <?php
                
                $sql= "SELECT* FROM employee";
                $results= mysqli_query($conn,$sql);
                $queryResults= mysqli_num_rows($results);
                
                if($queryResults>0){
                    while($row = mysqli_fetch_assoc($results)){
                      echo "<tr>
                      <td> ".$row['employee_id']."</td>
                       <td> ".$row['first_name']."</td>
                       <td> ".$row['middle_name']."</td>
                       <td> ".$row['last_name']."</td>
                       <td> ".$row['DOB']."</td>
                       <td> ".$row['gender']."</td>
                       <td> ".$row['phone_number']."</td>
                       <td> ".$row['email']."</td>
                       <td> ".$row['hourly_wage']."</td>
                       <td> ".$row['salary']."</td>
                       <td> ".$row['street_address']."</td>
                       <td> ".$row['state']."</td>
                       <td> ".$row['zip_code']."</td>
                       <td> ".$row['giftshop_id_fk']."</td>
                       <td> ".$row['event_id_fk']."</td>
                       <td> ".$row['restaurant_id_fk']."</td>
                       <td> ".$row['marketing_id_fk']."</td>
                       <td> ".$row['active_status']."</td>
                       <td> ".$row['attraction_id_fk']."</td>
                       <td> ".$row['maint_id_fk']."</td>
                       <td> ".$row['hire_date']."</td>
                       <td> ".$row['flag']."</td>
                       
                       </tr>";
                          
                    }
                }
                
               ?>

                </table>
              
            </div>
            
              
            
            <!--Section for Events-->
            
             <h2>All data in Events</h2>
            
            <div class="events-container">
                
               
                    <table>
                       
                       <tr>
                           
                           <th>Event Id</th>   
                           <th>Event Name</th>
                           <th>Event Date</th>
                           <th>Description</th>
                           <th>Begin Time</th>
                           <th>End Time</th>
                           <th>Rate/Hour</th>
                           <th>Venue Id</th>
                           <th>Flag</th>
                           
                       </tr>
                        
                        <?php
                
                $sql= "SELECT* FROM events";
                $results= mysqli_query($conn,$sql);
                $queryResults= mysqli_num_rows($results);
                
                if($queryResults>0){
                    while($row = mysqli_fetch_assoc($results)){
                      echo "
                      <tr>
                        <td> ".$row['event_id']."</td>
                       <td> ".$row['event_name']."</td>
                       <td> ".$row['event_date']."</td>
                       <td> ".$row['description']."</td>
                       <td> ".$row['begin_time']."</td>
                       <td> ".$row['end_time']."</td>
                       <td> ".$row['rate_per_hour']."</td>
                       <td> ".$row['venue_id_fk']."</td>
                       <td> ".$row['flag']."</td>
                       
                       </tr>";
                          
                    }
                }
                        ?>

                </table>
                
              
            </div>
            
            <!--Section for Gift Shop-->
            
            <h2>All data in Gift shop</h2>
            
            <div class="giftshop-container">
                
               
                    <table>
                       
                       <tr>
                           
                           <th>Gift Shop Id</th>
                           <th>Gift Shop Name</th>
                           <th>Opening Time</th>
                           <th>Closing Time</th>
                           <th>Location Id</th>
                           <th>Revenue</th>
                           <th>Utilities Cost</th>
                           <th>Flag</th>
                       
                       </tr>
                       
                <?php
                
                $sql= "SELECT* FROM gift_shop";
                $results= mysqli_query($conn,$sql);
                $queryResults= mysqli_num_rows($results);
                
                if($queryResults>0){
                    while($row = mysqli_fetch_assoc($results)){
                      echo "
                      <tr>
                       <td> ".$row['giftshop_id']."</td>
                       <td> ".$row['giftshop_name']."</td>
                       <td> ".$row['opening_time']."</td>
                       <td> ".$row['closing_time']."</td>
                       <td> ".$row['location_id_fk']."</td>
                       <td> ".$row['revenue']."</td>
                       <td> ".$row['utilities_cost']."</td>
                       <td> ".$row['flag']."</td>
                       
                       </tr>";
                          
                    }
                }
                
               ?>

                </table>
                
           
         
            </div>
            
            
            <!--Section for Location-->
            
            <h2>All data in Location</h2>
            
            <div class="location-container">
                
               
                    <table>
                       
                       <tr>
                           
                           <th>Location Id</th>
                           <th>Location Name</th>
                           <th>Location description</th>
                           <th>Flag</th>
                        
                       
                       </tr>
                       
                <?php
                
                $sql= "SELECT* FROM location";
                $results= mysqli_query($conn,$sql);
                $queryResults= mysqli_num_rows($results);
                
                if($queryResults>0){
                    while($row = mysqli_fetch_assoc($results)){
                      echo "<tr>
                       <td> ".$row['location_id']."</td>
                       <td> ".$row['location_name']."</td>
                       <td> ".$row['location_descripition']."</td>
                       <td> ".$row['flag']."</td>
    
                       
                       </tr>";
                          
                    }
                }
                
               ?>

                </table>
                
           
         
            </div>
            
            <!--Section for Maintenance Schedule-->
            
            <h2>All data in Maintenance Schedule</h2>
            
            <div class="maintenance_schedule-container">
                
               
                    <table>
                       
                       <tr>
                           
                           <th>Maintenance Id</th>
                           <th>Maintenance status </th>
                           <th>Date</th>
                           <th>Begin Time</th>
                           <th>End Time</th>
                           <th>Cost</th>
                           <th>Maintenance details</th>
                           <th>Restaurant ID</th>
                           <th>Ride ID</th>
                           <th>Venue ID</th>
                           <th>Gift Shop ID</th>
                           <th>Flag</th>
                       
                       </tr>
                       
                <?php
                
                $sql= "SELECT* FROM maintenance_schedules";
                $results= mysqli_query($conn,$sql);
                $queryResults= mysqli_num_rows($results);
                
                if($queryResults>0){
                    while($row = mysqli_fetch_assoc($results)){
                      echo "<tr>
                       <td> ".$row['maintenance_id']."</td>
                       <td> ".$row['maint_status']."</td>
                       <td> ".$row['date']."</td>
                       <td> ".$row['begin_time']."</td>
                       <td> ".$row['end_time']."</td>
                       <td> ".$row['cost']."</td>
                       <td> ".$row['maintenance_details']."</td>
                       <td> ".$row['restaurant_id_fk']."</td>
                        <td> ".$row['ride_id_fk']."</td>
                        <td> ".$row['venue_id_fk']."</td>
                        <td> ".$row['giftshop_id_fk']."</td>
                        <td> ".$row['flag']."</td>
                       
                       </tr>";
                          
                    }
                }
                
               ?>

                </table>
                
           
         
            </div>
            
            <!--Section for Marketing-->
            
            <h2>All data in Marketing</h2>
            
            <div class="marketing-container">
                
               
                    <table>
                       
                       <tr>
                           
                           <th>Marketing Id</th>
                           <th>Advertisement type</th>
                           <th>Begin date</th>
                           <th>End date</th>
                           <th>Cost</th>
                           <th>Description</th>
                           <th>Flag</th>
                           
                       
                       </tr>
                       
                <?php
                
                $sql= "SELECT* FROM marketing";
                $results= mysqli_query($conn,$sql);
                $queryResults= mysqli_num_rows($results);
                
                if($queryResults>0){
                    while($row = mysqli_fetch_assoc($results)){
                      echo "<tr>
                      
                       <td> ".$row['marketing_id']."</td>
                       <td> ".$row['advertisement_type']."</td>
                       <td> ".$row['begin_date']."</td>
                       <td> ".$row['end_date']."</td>
                       <td> ".$row['cost']."</td>
                       <td> ".$row['description']."</td>
                       <td> ".$row['flag']."</td>
            
                       </tr>";
                          
                    }
                }
                
               ?>

                </table>
                
           
         
            </div>
            
            <!--Section for Parking-->
            
            <h2>All data in Parking</h2>
            
            <div class="parking-container">
                
               
                    <table>
                       
                       <tr>
                           
                           <th>Parking Id</th>
                           <th>Cost</th>
                           <th>Customer Id</th>
                           <th>Location Id</th>
                           <th>Flag</th>
                        
                       
                       </tr>
                       
                <?php
                
                $sql= "SELECT* FROM parking";
                $results= mysqli_query($conn,$sql);
                $queryResults= mysqli_num_rows($results);
                
                if($queryResults>0){
                    while($row = mysqli_fetch_assoc($results)){
                      echo "<tr>
                       <td> ".$row['parking_id']."</td>
                       <td> ".$row['cost']."</td>
                       <td> ".$row['customer_id_fk']."</td>
                       <td> ".$row['location_id_fk']."</td>
                       <td> ".$row['flag']."</td>
                       
                       </tr>";
                          
                    }
                }
                
               ?>

                </table>
                
           
         
            </div>
                
                
                
                
                
            
            <!--Section for Restaurants-->
            
            <h2>All data in Restaurant</h2>
            
            <div class="restaurant-container">
                
               
                    <table>
                       
                       <tr>
                           
                           <th>Restaurant Id</th>
                           <th>Restaurant Name</th>
                           <th>Opening Time</th>
                           <th>Closing Time</th>
                           <th>Location Id</th>
                           <th>Revenue</th>
                           <th>Utilities Cost</th>
                           <th>Flag</th>
                       
                       </tr>
                       
                <?php
                
                $sql= "SELECT* FROM restaurant";
                $results= mysqli_query($conn,$sql);
                $queryResults= mysqli_num_rows($results);
                
                if($queryResults>0){
                    while($row = mysqli_fetch_assoc($results)){
                      echo "<tr>
                       <td> ".$row['restaurant_id']."</td>
                       <td> ".$row['restaurant_name']."</td>
                       <td> ".$row['opening_time']."</td>
                       <td> ".$row['closing_time']."</td>
                       <td> ".$row['location_id_fk']."</td>
                       <td> ".$row['revenue']."</td>
                       <td> ".$row['utilities_cost']."</td>
                       <td> ".$row['flag']."</td>
                       
                       </tr>";
                          
                    }
                }
                
               ?>

                </table>
                
           
         
            </div>
            
            
            <!--Section for Tickets-->
            
            <h2>All data in Tickets</h2>
            
            <div class="tickets-container">
                
               
                    <table>
                       
                       <tr>
                           
                           <th>Ticket Id</th>
                           <th>Fastpass </th>
                           <th>Price </th>
                           <th>Date</th>
                           <th>Customer ID</th>
                           <th>Flag</th>
                       
                       </tr>
                       
                <?php
                
                $sql= "SELECT* FROM tickets";
                $results= mysqli_query($conn,$sql);
                $queryResults= mysqli_num_rows($results);
                
                if($queryResults>0){
                    while($row = mysqli_fetch_assoc($results)){
                      echo "<tr>
                       <td> ".$row['ticket_id']."</td>
                       <td> ".$row['fastpass']."</td>
                       <td> ".$row['price']."</td>
                       <td> ".$row['date']."</td>
                       <td> ".$row['customer_fk_id']."</td>
                       <td> ".$row['flag']."</td>
                       
                       </tr>";
                          
                    }
                }
                
               ?>

                </table>
                
           
         
            </div>
            
            <!--Section for Venue-->
            
            <h2>All data in Venue</h2>
            
            <div class="venue-container">
                
               
                    <table>
                       
                       <tr>
                           
                           <th>Venue Id</th>
                           <th>Venue Name</th>
                           <th>Description</th>
                           <th>Location ID</th>
                           <th>Flag</th>
    
                       
                       </tr>
                       
                <?php
                
                $sql= "SELECT* FROM venue";
                $results= mysqli_query($conn,$sql);
                $queryResults= mysqli_num_rows($results);
                
                if($queryResults>0){
                    while($row = mysqli_fetch_assoc($results)){
                      echo "<tr>
                       <td> ".$row['venue_id']."</td>
                       <td> ".$row['venue_name']."</td>
                       <td> ".$row['description']."</td>
                        <td> ".$row['location_id_fk']."</td>
                        <td> ".$row['flag']."</td>
                       
                       </tr>";
                          
                    }
                }
                
               ?>

                </table>
                
         
            </div>
                    
            
</body>
</html>
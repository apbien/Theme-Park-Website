<?php  include('../config.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Shops</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
  <?php require_once 'Shopsproc.php'; ?>
  <?php 
  if(isset($_SESSION['message'])):
  ?>

<div class="alert alert-<?=$_SESSION['msg_type']?>">
  <?php 
  echo $_SESSION['message'];
  unset($_SESSION['message']);
  ?>
</div>
  <?php endif?>

  <?php
  $result = $conn-> query("SELECT gift_shop.*, maintenance_schedules.date from gift_shop join maintenance_schedules on (gift_shop.giftshop_id = maintenance_schedules.giftshop_id_fk) group by gift_shop.giftshop_id") or die($conn->error);
  ?>
<div class="container">
  <h1 class="vertical-center" style="text-align:center;background-color:#000000;color: aliceblue;min-height:15vh;">Gift Shops Data Management Form</h1>      
  <br>
<div>

  <form id="ShopsForm" method="post" class="form-horizontal" action="Shopsproc.php"> <div>
  <input type="hidden" name="id" value= "<?php echo $id;?>">
  
  
    <nav class="navbar-form" style="background:whitesmoke">
        <div class="nav navbar-nav navbar-right">
          <?php 
          if ($update == true):
          ?>
          <button type="submit" class="btn btn-info" name= "btnUpdate">Update</button>
          <?php else: ?>
          <button type="submit" class="btn btn-primary" name= "btnSave">Save</button>
          <?php endif; ?>
        </div> <br> <br>
    </nav>
  </div>

      <?php include('errors.php'); ?>
    <div class="form-group">
      <label class="control-label col-sm-2">Name:</label>
      <div class="col-sm-5">
        <input type="text" class="form-control" placeholder="Enter Gift Shop Name" value="<?php echo $giftshop_name; ?>" name="giftshop_name">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2">Merchandise list:</label>
      <div class="col-sm-5">
        <input type="text" class="form-control" placeholder="Enter Merchandise List" value="<?php echo $merchandise_list; ?>" name="merchandise_list" >
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2">Utilities Cost</label>
      <div class="col-sm-5">
        <input type="number" class="form-control" placeholder="Enter Utility Cost" value="<?php echo $utilities_cost; ?>" name="utilities_cost">
      </div>
    </div>
    
    <div class="form-group">
      <label class="control-label col-sm-2">Revenue</label>
      <div class="col-sm-5">
        <input type="number" class="form-control" placeholder="Enter Revenue" value="<?php echo $revenue; ?>" name="revenue">
      </div>
    </div>
 
    <div class="form-group">
      <label class="control-label col-sm-2">Opening Time:</label>
      <div class="col-sm-5">
        <input type="time" class="form-control" placeholder="Enter Opening Time" value="<?php echo $opening_time; ?>" name="opening_time">
      </div>
    </div>
    
    <div class="form-group">
      <label class="control-label col-sm-2" for="loc">Closing Time</label> 
      <div class="col-sm-5">
        <input type="time" class="form-control" placeholder="Enter Closing Time" value="<?php echo $closing_time; ?>" name="closing_time">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="loc">Location</label> 
      <div class="col-sm-5">
        <select class="form-control" placeholder="Enter Location Id" value="<?php echo $location_id_fk; ?>" name="location_id_fk">
          <option value = "1A" >1A</option>
          <option value = "1B" >1B</option>
          <option value = "1C" >1C</option>
          <option value = "2A" >2A</option>
          <option value = "2B" >2B</option>
          <option value = "2C" >2C</option>
          <option value = "3A" >3A</option>
          <option value = "3B" >3B</option>
          <option value = "3C" >3C</option>
          <option value = "4A" >4A</option>
          <option value = "4B" >4B</option>
          <option value = "4C" >4C</option>
          <option value = "5A" >5A</option>
          <option value = "5B" >5B</option>
          <option value = "5C" >5C</option>
          </select>
	    </div>
    </div>

  </form>

    <form>
    <button type="submit" class="btn btn-success" formaction="maint_gift.php">Manage Gift Shop Management Schedule</button>
    <button type="submit" class="btn btn-dark" formaction="dashboard.php">Return to Management Page</button>
  </form>

  <script>
    function myFunction() {
      document.getElementById("myForm").reset();
    }
</script>

  <br>
  <br>
  <br>
 
  <div cLass="row justify-content-center">
    <table class="table table-striped table-bordered table-hover table-condensed">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Merchandise List</th>
          <th>UtilityCost</th>
          <th>Revenue</th>
        <th>OpeningTime</th>
          <th>ClosingTime</th>
          <th>Location</th>
          <th>Last Maintenance</th>
          <th colspan="2">Action</th>
        </tr>
      </thead>
    <?php while($row = $result->fetch_assoc()): ?>
      <?php if($_SESSION['employee']['manager_status'] == "Y" && $row['flag'] == 0): ?>
              <tr>
            <td><?php echo $row['giftshop_id']; ?></td>
            <td><?php echo $row['giftshop_name']; ?></td>
            <td><?php echo $row['merchandise_list']; ?></td>
            <td><?php echo $row['utilities_cost']; ?></td>
          <td><?php echo $row['revenue']; ?></td>
            <td><?php echo $row['opening_time']; ?></td>
            <td><?php echo $row['closing_time']; ?></td>
            <td><?php echo $row['location_id_fk']; ?></td> 
            <td><?php echo $row['date']; ?></td>
            <td>
              <a href="Shops.php?edit=<?php echo $row['giftshop_id'];?>"
              class="btn btn-info">Edit</a>
              <a href="Shops.php?delete=<?php echo $row['giftshop_id'];?>"
              class="btn btn-danger">Delete</a>          
            </td>
          </tr>
      <?php endif ?>
      <?php if($_SESSION['employee']['manager_status'] == "A" && $row['flag'] < 2): ?>
              <tr>
            <td><?php echo $row['giftshop_id']; ?></td>
            <td><?php echo $row['giftshop_name']; ?></td>
            <td><?php echo $row['merchandise_list']; ?></td>
            <td><?php echo $row['utilities_cost']; ?></td>
          <td><?php echo $row['revenue']; ?></td>
            <td><?php echo $row['opening_time']; ?></td>
            <td><?php echo $row['closing_time']; ?></td>
            <td><?php echo $row['location_id_fk']; ?></td> 
            <td><?php echo $row['date']; ?></td>
            <td>
              <a href="Shops.php?edit=<?php echo $row['giftshop_id'];?>"
              class="btn btn-info">Edit</a>
              <a href="Shops.php?delete=<?php echo $row['giftshop_id'];?>"
              class="btn btn-danger">Delete</a>          
            </td>
          </tr>
      <?php endif ?>


      <?php endwhile; ?>
    </table>
  </div>
  </div>
</div>

</body>
</html>
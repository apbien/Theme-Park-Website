<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Month', 'General Maint.'],
          ['Janurary', 0],
          ['Febraury', 0],
          ['March', 0],
          ['April', 8],
          ['May', 21],
          ['June', 18],
          ['July', 19],
          ['August', 20],
          ['September', 16],
          ['October', 20],
          ['November', 23],
          ['December', 19]
        ]);

        var options = {
          chart: {
            title: 'Amount of General Maint. vs Month',
          }
        };

        vAxis: {
          title: 'General Maint.'
        }

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>
  </head>
  <body>
    <div id="columnchart_material" style="width: 800px; height: 500px;"></div>
      164 total general scheduled maintenance 2018, ~13.66 Maintenance Days Per Month
       <form>
    <button type="submit" class="btn btn-dark" formaction="../charts.php">Return to Report Page</button>
  </form>
  </body>
</html>
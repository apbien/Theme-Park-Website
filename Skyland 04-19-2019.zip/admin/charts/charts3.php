<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Month', 'General Maint.'],
          ['Janurary', 0],
          ['Febraury', 0],
          ['March', 0],
          ['April', 0],
          ['May', 1],
          ['June', 3],
          ['July', 3],
          ['August', 3],
          ['September', 1],
          ['October', 6],
          ['November', 1],
          ['December', 0]
        ]);

        var options = {
          chart: {
            title: 'Amount of rides broken down per month',
          }
        };

        vAxis: {
          title: 'Broken Down.'
        }

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>
  </head>
  <body>
    <div id="columnchart_material" style="width: 800px; height: 500px;"></div>
      164 total general scheduled maintenance 2018, ~13.66 Maintenance Days Per Month
     <form>
    <button type="submit" class="btn btn-dark" formaction="../charts.php">Return to Report Page</button>
  </form>
  </body>
</html>
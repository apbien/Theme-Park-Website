<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Month', 'General Maint.'],
          ['Janurary', 0],
          ['Febraury', 0],
          ['March', 0],
          ['April', 8],
          ['May', 9],
          ['June', 9],
          ['July', 9],
          ['August', 8],
          ['September', 13],
          ['October', 5],
          ['November', 6],
          ['December', 12]
        ]);


        var options = {
          chart: {
            title: 'Rides Rain Out vs Month',
          }
        };

        vAxis: {
          title: 'Rain Outs'
        }

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>
  </head>
  <body>

    <div id="columnchart_material" style="width: 800px; height: 500px;"></div>
     79 days of Rain of 2018, ~6.5833 Rain Days Per Month
     <form>
    <button type="submit" class="btn btn-dark" formaction="../charts.php">Return to Report Page</button>
  </form>
</html>
  </body>
</html>
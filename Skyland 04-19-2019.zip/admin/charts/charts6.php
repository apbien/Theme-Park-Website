<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Month', 'Customer.'],
          ['Janurary', 0],
          ['Febraury', 0],
          ['March', 0],
          ['April', 21],
          ['May', 16],
          ['June', 27],
          ['July', 55],
          ['August', 39],
          ['September', 13],
          ['October', 41],
          ['November', 23],
          ['December', 45]
        ]);

        var options = {
          chart: {
            title: 'Month vs Customers',
          }
        };

        vAxis: {
          title: 'Customer.'
        }

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>
  </head>
  <body>
    <div id="columnchart_material" style="width: 800px; height: 500px;"></div>
    <form>
    <button type="submit" class="btn btn-dark" formaction="../charts.php">Return to Report Page</button>
  </form>
  </body>
</html>
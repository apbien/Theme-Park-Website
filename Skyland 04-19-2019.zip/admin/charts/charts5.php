<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart', 'bar']});
      google.charts.setOnLoadCallback(drawStuff);

      function drawStuff() {

        var button = document.getElementById('change-chart');
        var chartDiv = document.getElementById('chart_div');

        var data = google.visualization.arrayToDataTable([
          ['Cost of Stuff', 'Profit Gain', 'Profit Loss'],
          ['Maint-Broke Down', 0, 296587],
          ['Rain Out', 0, 521628],
          ['General-Maint', 0, 999826],
          ['Restaurant', 8318141, 2876411.77],
          ['Gift Shop', 382388.95, 148834.95],
          ['Marketing', 0, 45247],
          ['Parking', 780, 0],
          ['Tickets', 11730, 0],
          ['Events', 30178000, 0],
          ['Employee-Hourly', 0, 24381],
          ['Employee-Salary', 0, 202982]

        ]);

        var materialOptions = {
          width: 900,
          chart: {
            title: 'Profit Gain vs Profit Loss (2018)',
          },
          series: {
            0: { axis: 'distance' }, // Bind series 0 to an axis named 'distance'.
            1: { axis: 'brightness' } // Bind series 1 to an axis named 'brightness'.
          },
          axes: {
            y: {
              distance: {label: 'parsecs'}, // Left y-axis.
              brightness: {side: 'right', label: 'apparent magnitude'} // Right y-axis.
            }
          }
        };

        var classicOptions = {
          width: 900,
          series: {
            0: {targetAxisIndex: 0},
            1: {targetAxisIndex: 1}
          },
          title: 'Nearby galaxies - distance on the left, brightness on the right',
          vAxes: {
            // Adds titles to each axis.
            0: {title: 'parsecs'},
            1: {title: 'apparent magnitude'}
          }
        };

        function drawMaterialChart() {
          var materialChart = new google.charts.Bar(chartDiv);
          materialChart.draw(data, google.charts.Bar.convertOptions(materialOptions));
          button.innerText = 'Change to Classic';
          button.onclick = drawClassicChart;
        }

        function drawClassicChart() {
          var classicChart = new google.visualization.ColumnChart(chartDiv);
          classicChart.draw(data, classicOptions);
          button.innerText = 'Change to Material';
          button.onclick = drawMaterialChart;
        }

        drawMaterialChart();
    };
    </script>
  </head>
  <body>
    <button id="change-chart">Change to Classic</button>
    <br><br>
    <div id="chart_div" style="width: 800px; height: 500px;"></div>

    Profit Loss: $5116167.72 and Profit Gain: $38891039.95
    <form>
    <button type="submit" class="btn btn-dark" formaction="../charts.php">Return to Report Page</button>
  </form>
  </body>
</html>
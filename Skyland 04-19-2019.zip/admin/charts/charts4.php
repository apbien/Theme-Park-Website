<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Attractions', 'Amount of Break down per Ride'],
          ['1', 1],
          ['2', 3],
          ['3', 3],
          ['4', 2],
          ['5', 0],
          ['6', 3],
          ['7', 6]
        ]);

        var options = {
          title: 'Amount of Break Down Per Rides'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="piechart" style="width: 900px; height: 500px;"></div>
    <form>
    <button type="submit" class="btn btn-dark" formaction="../charts.php">Return to Report Page</button>
  </form>
  </body>
</html>
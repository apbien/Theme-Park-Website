<?php

$update = false;
$id = '';
$maint_id = '';
$date ='';
$begin = "";
$end = '';
$cost = '';
$status = '';
$details = '';
$foreignkey = '';
$location = '';
$errors = array();

	
if (isset($_POST['btnSave']))
{
	$date = $_POST['date'];
	$begin = $_POST['begin'];
	$end = $_POST['end'];
	$cost = $_POST['cost'];
	$status = $_POST['status'];
	$details = $_POST['details'];
	$location = $_POST['location'];


	//if any of the input fields were blank, put an error string into the errors array
		if(empty($date)){
			array_push($errors, "Date is required.");
		}
		if(empty($begin)){
			array_push($errors, "Begin Time is required.");
		}
		if(empty($end)){
			array_push($errors, "End Time is required.");
		}
		if(empty($status)){
			array_push($errors, "Status is required.");
		}
		if(empty($details)){
			array_push($errors, "Details is required.");
		}
		if(empty($location)){
			echo $location;
			array_push($errors, "Location is required.");
		}
	//if the no errors are in the array
	if(count($errors)==0)
	{
		$result = $conn-> query("SELECT giftshop_id FROM gift_shop WHERE '$location' = giftshop_name");
		$fk = '';
		while($row = $result->fetch_assoc()){
			$fk = $row['giftshop_id'];
		}
		if(empty($cost)){
			$sql = "INSERT INTO maintenance_schedules(date, begin_time, end_time, cost, maint_status, maintenance_details, giftshop_id_fk) 
			VALUES ('$date','$begin','$end',NULL,'$status','$details',$fk)";
		}else{
			$sql = "INSERT INTO maintenance_schedules(date, begin_time, end_time, cost, maint_status, maintenance_details, giftshop_id_fk) 
			VALUES ('$date','$begin','$end','$cost','$status','$details',$fk)";
		}
		if (mysqli_query($conn, $sql)) {
			  echo"Maintenance Schedule was successfully added!";
		} else {
			  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		$conn->close();

		
		
	}
} 

if (isset($_GET['delete']))
{
    $id = $_GET['delete'];
    $conn->query("DELETE FROM maintenance_schedules WHERE maintenance_id=$id") or die($conn->error);
   
    $_SESSION['message'] = "Record has been deleted!";
    $_SESSION['msg_type']="danger";
    header("location: maint_gift.php");
}

if (isset($_GET['edit']))
{
    $id = $_GET['edit'];
    $update = true;
	$result= $conn->query("SELECT maintenance_schedules.*, gift_shop.giftshop_name FROM maintenance_schedules JOIN gift_shop ON maintenance_schedules.giftshop_id_fk = gift_shop.giftshop_id WHERE maintenance_id=$id") or die($conn->error);
    if ($result == true)
    {
        $row=$result->fetch_array();
        $maint_id = $row['maintenance_id'];
		$date = $row['date'];
		$begin = $row['begin_time'];
		$end = $row['end_time'];
		$cost = $row['cost'];
		$status = $row['maint_status'];
		$details = $row['maintenance_details'];
		$location = $row['giftshop_name'];
		
		
        
    }
}

if (isset($_POST['btnUpdate']))
{
    $id = $_POST['id'];
	$date = $_POST['date'];
	$begin = $_POST['begin'];
	$end = $_POST['end'];
	$cost = $_POST['cost'];
	$status = $_POST['status'];
	$details = $_POST['details'];
	$location = $_POST['location'];
	$result = $conn-> query("SELECT giftshop_id FROM gift_shop WHERE '$location' = giftshop_name");
	$fk = '';
	while($row = $result->fetch_assoc()){
		$fk = $row['giftshop_id'];
	}
		if(empty($cost)){
			$conn->query("UPDATE maintenance_schedules SET date = '$date', begin_time = '$begin',end_time = '$end', cost = NULL, maint_status = '$status', maintenance_details = '$details', giftshop_id_fk = $fk WHERE (maintenance_id =$id)") or die($conn->error);
		}else{
			$conn->query("UPDATE maintenance_schedules SET date = '$date', begin_time = '$begin',end_time = '$end', cost = '$cost', maint_status = '$status', maintenance_details = '$details', giftshop_id_fk = $fk WHERE (maintenance_id = $id)") or die($conn->error);
		}
	$_SESSION['message'] = "Record has been updated!";
    $_SESSION['msg_type']="warning";
    header("location: maint_gift.php");
}

?>

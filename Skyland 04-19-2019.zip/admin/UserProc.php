<?php

$update = false;
$id = '';
$first_name = '';
$middle_name ='';
$last_name = '';
$DOB = '';
$gender = '';
$hours = '';
$hourly_wage = '';
$phone_number = '';
$email = '';
$password ='';
$street_address = '';
$state = '';
$zip_code = '';
$hire_date = '';
$manager_status = '';
$active_status = '';
$errors = array();

if (isset($_POST['btnSave']))
{
    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name'];
    $last_name = $_POST['last_name'];
    $DOB = $_POST['DOB']; 
    $gender= $_POST['gender'];
    $hours  = $_POST['hours'];  
    $hourly_wage  = $_POST['hourly_wage']; 
    $phone_number = $_POST['phone_number'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $street_address = $_POST['street_address']; 
    $state= $_POST['state'];
    $zip_code  = $_POST['zip_code'];  
    $hire_date  = $_POST['hire_date']; 
    $manager_status  = $_POST['manager_status'];  
    $active_status  = $_POST['active_status'];

        if(empty($first_name)){
            array_push($errors, "First Name is required.");
        }
        if(empty($middle_name)){
            array_push($errors, "Middle Name is required.");
        }
        if(empty($last_name)){
            array_push($errors, "Last Name is required.");
        }
        if(empty($DOB)){
            array_push($errors, "Date of Birth is required.");
        }
        if(empty($gender)){
            array_push($errors, "Gender is required.");
        }
        if(empty($hours)){
            array_push($errors, "Hours is required.");
        }
        if(empty($hourly_wage)){
            array_push($errors, "Hourly Wage is required.");
        }
        if(empty($phone_number)){
            array_push($errors, "Phone Number is required.");
        }
        if(empty($email)){
            array_push($errors, "Email is required.");
        }
        if(empty($password)){
            array_push($errors, "Password is required.");
        }
        if(empty($street_address)){
            array_push($errors, "Street Address is required.");
        }
        if(empty($state)){
            array_push($errors, "State is required.");
        }
        if(empty($zip_code)){
            array_push($errors, "Zip Code is required.");
        }
        if(empty($hire_date)){
            array_push($errors, "Hire Date is required.");
        }
        if(empty($manager_status)){
            array_push($errors, "Manager Status is required.");
        }
        if(empty($active_status)){
            array_push($errors, "Active Status is required.");
        }

        if(count($errors)==0){


            $sql = "INSERT INTO employee(first_name,middle_name,last_name,DOB,gender,hours,hourly_wage,phone_number,email,password,street_address,state,zip_code, hire_date, manager_status,active_status)
            VALUES('$first_name','$middle_name','$last_name', '$DOB','$gender','$hours','$hourly_wage','$phone_number','$email','$password','$street_address','$state','$zip_code', '$hire_date', '$manager_status','$active_status')";
            if (mysqli_query($conn, $sql)) {
             $_SESSION['message'] ="Employee was successfully added!";
            } else {
                  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }
            
            $conn->close();

        }
} 



if (isset($_GET['delete']))
{
    $id = $_GET['delete'];
    $update = true;
    if($_SESSION['employee']['manager_status'] == 'Y'){
        $conn->query("UPDATE employee SET  flag= 1 WHERE (employee_id =$id)") or die($conn->error);
    }else if($_SESSION['employee']['manager_status'] == 'A'){
        $conn->query("UPDATE employee SET  flag= 2 WHERE (employee_id =$id)") or die($conn->error);
    }
   
    $_SESSION['message'] = "Record has been flagged for deletion!";
    $_SESSION['msg_type']="danger";
    header("location: users.php");
}

if (isset($_GET['edit']))
{
    $id = $_GET['edit'];
    $update = true;
    $result= $conn->query("SELECT * FROM employee WHERE employee_id=$id") or die($conn->error);
    if ($result == true)
    {
        $row=$result->fetch_array();
        $first_name = $row['first_name'];
        $middle_name = $row['middle_name'];
        $last_name = $row['last_name'];
        $DOB = $row['DOB'];
        $gender = $row['gender']; 
        $hours= $row['hours']; 
        $hourly_wage  = $row['hourly_wage']; 
        $phone_number  = $row['phone_number'];  
        $email = $row['email'];
        $password = $row['password'];
        $street_address = $row['street_address'];
        $state = $row['state'];
        $zip_code = $row['zip_code']; 
        $hire_date= $row['hire_date']; 
        $manager_status  = $row['manager_status']; 
        $active_status  = $row['active_status'];   
    }
}

if (isset($_POST['btnUpdate']))
{
    $id = $_POST['id'];
    $first_name= $_POST['first_name'];
    $middle_name     = $_POST['middle_name'];
    $last_name = $_POST['last_name'];
    $DOB = $_POST['DOB']; 
    $gender = $_POST['gender']; 
    $hours = $_POST['hours']; 
    $hourly_wage = $_POST['hourly_wage']; 
    $phone_number = $_POST['phone_number'];
    $email= $_POST['email'];
    $password     = $_POST['password'];
    $street_address = $_POST['street_address'];
    $state = $_POST['state']; 
    $zip_code = $_POST['zip_code']; 
    $hire_date = $_POST['hire_date']; 
    $manager_status = $_POST['manager_status']; 
    $active_status = $_POST['active_status'];



    $conn->query("UPDATE employee SET first_name= '$first_name', middle_name= '$middle_name' ,last_name = '$last_name',DOB = '$DOB',gender='$gender',hours= '$hours', hourly_wage='$hourly_wage', phone_number= '$phone_number', email= '$email' ,password = '$password',street_address = '$street_address',state='$state',zip_code= '$zip_code', hire_date='$hire_date',manager_status= '$manager_status', active_status='$active_status' WHERE employee_id =$id") or die($conn->error);
    $_SESSION['message'] = "Record has been updated!";
    $_SESSION['msg_type']="warning";
    header("location: users.php");
}

?>

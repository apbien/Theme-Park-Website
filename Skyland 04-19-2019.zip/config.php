<?php 
	session_start();

	// connect to database
    $conn = mysqli_connect("skyland-mysqldbserver.mysql.database.azure.com", "skylandadmin@skyland-mysqldbserver", "Themepark4", "skylanddatabase");

	if (!$conn) {
		die("Error connecting to database: " . mysqli_connect_error());
	}

	define ('ROOT_PATH', realpath(dirname(__FILE__))); //path to root folder
	define('BASE_URL', 'https://skyland.azurewebsites.net/'); //BASE URL
?>
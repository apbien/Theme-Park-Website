<?php  include('../config.php'); ?>

<!DOCTYPE html>
<html>
    <head>
        
        <title> LOOK UP TABLE </title>
        <style> 
            table,tr, th,td{
                border: 1px solid black;
            }
        </style>
        
        <link rel="stylesheet" type="text/css" href="stylesheets/style_search.css"/>
         
    </head>
        <body>
              
            <form action=" employeesearch1.php" method="POST"> 
                <input type= "text" name ="search" placeholder= "Search">
                <button type="submit" name="submit-search">Search</button>

                <button type="submit" class="btn btn-success" formaction="employee.php">Return to Employee Page</button>
            </form>
            
            <h1>LOOK UP TABLE</h1>
            
            <!--Section for employees-->
            
            <h2>All Employees data </h2>
            
            <div class="employee-container">
                
               
                    <table>
                       
                      <tr>
                           
                           <th>First Name</th>
                           <th>Middle Name</th>
                           <th>Last Name</th>
                           <th>Email</th>
                           <th>Gift Shop ID</th>
                           <th>Event ID</th>
                           <th>Restaurant ID</th>
                           <th>Marketing ID</th>
                           <th>Active Status ID</th>
                           <th>Attraction ID</th>
                           <th>Maintenance ID</th>
                    
                       
                       </tr>
                <?php
                
                $sql= "SELECT* FROM employee";
                $results= mysqli_query($conn,$sql);
                $queryResults= mysqli_num_rows($results);
                
                if($queryResults>0){
                    while($row = mysqli_fetch_assoc($results)){
                      echo "<tr>

                       <td> ".$row['first_name']."</td>
                       <td> ".$row['middle_name']."</td>
                       <td> ".$row['last_name']."</td>
                       <td> ".$row['email']."</td>
                       <td> ".$row['giftshop_id_fk']."</td>
                       <td> ".$row['event_id_fk']."</td>
                       <td> ".$row['restaurant_id_fk']."</td>
                       <td> ".$row['marketing_id_fk']."</td>
                       <td> ".$row['active_status']."</td>
                       <td> ".$row['attraction_id_fk']."</td>
                       <td> ".$row['maint_id_fk']."</td>
                       
                       </tr>";
                          
                    }
                }
                
               ?>

                </table>
              
            </div>                    
            
</body>
</html>
<?php  include('../config.php'); ?>

<!DOCTYPE html>
<html>
    <head>
        
        <title> Look Up table </title>
        <link rel="stylesheets" type="text/css" href="style.css">
        <style> 
            table,tr, th,td{
                border: 1px solid black;
            }
        </style>
    </head>
        <body>
           

<h1> Search Page </h1>
<form>
   <button type="submit" class="btn btn-success" formaction="employeesearch.php">Return to Search</button>
  <button type="submit" class="btn btn-success" formaction="employee.php">Return to Employee Page</button>
</form>
            <!--Employee Search-->
<h2> Results in EMPLOYEE </h2>

<div class="employee-container">
      
  <?php
    
    if(isset($_POST['submit-search'])){
        $search= mysqli_real_escape_string($conn, $_POST['search']);
        
        $sql= "SELECT* FROM employee WHERE employee_id LIKE '%$search%' 
        OR first_name LIKE '%$search%' 
        OR middle_name LIKE '%$search%' 
        OR last_name LIKE '%$search%' 
        OR email LIKE '%$search%' 
        OR giftshop_id_fk LIKE '%$search%'
        OR event_id_fk LIKE '%$search%'
        OR restaurant_id_fk LIKE '%$search%' 
        OR marketing_id_fk LIKE '%$search%' 
        OR active_status LIKE '%$search%'
        OR attraction_id_fk LIKE '%$search%' 
        OR maint_id_fk LIKE '%$search%' 
        ";
        
        
        
        
        $result= mysqli_query($conn,$sql);
        $queryResult= mysqli_num_rows($result);
    }
    ?>
    
    
    
    <div class="event-container">             
 
    <?php
    if($queryResult >0){
         while($row= mysqli_fetch_assoc($result)){  
            echo "<table>
                       
                        <tr>
                           <th>Employee Id</th>
                           <th>First Name</th>
                           <th>Middle Name</th>
                           
                           <th>Last Name</th>
                           
                           <th>Phone Number</th>
                           <th>Email</th>

                           
                           <th>Gift Shop ID</th>
                           <th>Event ID</th>
                           <th>Restaurant ID</th>
                           <th>Marketing ID</th>
                           <th>Active Status ID</th>
                           <th>Attraction ID</th>
                           <th>Maintenance ID</th>
    
                           
                       
                       </tr>
                       
                <tr>

                       <td> ".$row['first_name']."</td>
                       <td> ".$row['middle_name']."</td>
                       <td> ".$row['last_name']."</td>
                       <td> ".$row['email']."</td>
        
                       <td> ".$row['giftshop_id_fk']."</td>
                       <td> ".$row['event_id_fk']."</td>
                       <td> ".$row['restaurant_id_fk']."</td>
                       <td> ".$row['marketing_id_fk']."</td>
                       <td> ".$row['active_status']."</td>
                       <td> ".$row['attraction_id_fk']."</td>
                       <td> ".$row['maint_id_fk']."</td>
            
                       
                       
                       </tr>
                        </table>";

         }
        }
        else{
            echo "There are no results matching your search in the employee table";
        }
    ?>
                        
                   
              
            </div>    
    
</div>
            
            </body>
</html>
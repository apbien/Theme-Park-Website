<?php	
$id = "";
$id = $_SESSION['employee']['email'];

$sql = "SELECT street_address,state,zip_code FROM employee WHERE email= '$id'";
	$result = $conn->query($sql);
	while($row = $result-> fetch_assoc()){
		
		$street=$row["street_address"];
		$state = $row["state"];
		$zip = $row["zip_code"];
	}
	$errors = array();

//when the user clicks the Cancel Button on the AddressChange Page
	
	if(isset($_POST['cancel'])){
		header('location: employee.php');
		$conn->close();
	}
	if(isset($_POST['change'])){
		$street = ($_POST['street']);
		$state = ($_POST['state']);
		$zip = ($_POST['zip']);
		//if any of the input fields were blank, put an error string into the errors array
		if(empty($street)){
			array_push($errors, "Street Address is required.");
		}
		if(empty($state)){
			array_push($errors, "State is required.");
		}
		if(empty($zip)){
			array_push($errors, "Zip Code is required.");
		}
		//if the no errors are in the array
		if(count($errors)==0)
		{
			
			//create an error if the connection to the database fails
			if(mysqli_connect_error()){
				die('Connect Error ('. mysqli_connect_errno() .') '. mysqli_connect_error());
			}else{
				$sql = "UPDATE employee SET street_address = '$street', state = '$state', zip_code='$zip' WHERE email= '$id'";
				mysqli_query($conn, $sql);
				header('location: employee.php');
			} 
			$conn->close();					
		}
			
	}
?>
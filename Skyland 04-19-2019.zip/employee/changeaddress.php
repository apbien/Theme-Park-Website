<?php  include('../config.php'); ?>
<?php include ('change_server.php'); ?>
<!DOCTYPE html>
<html>
<head>
		<!-- Styling for public area -->
	<link rel="stylesheet" href="includes/style_employee.css">
	<meta charset="UTF-8">
	<title> Employee Home Page </title>
</head>
<body>
	<!-- container - wraps whole page -->
	<div class="container">
		<!-- navbar -->
		<div class="navbar">
			
			<div class="buttons">
				<ul>
					<li><a href="employee.php">Home</a></li>
					<li><a href="/logout.php">Logout</a></li>
				</ul>
			</div>
			<div class="logo_div">
				<?php
					$id = "";
					$id = $_SESSION['employee']['email'];
					//CHANGE: for the line of code under this one, change (WHERE employee_id = 1) to the current logged in user
					$sql = "SELECT first_name,last_name FROM employee WHERE email= '$id'";
					$result = $conn-> query($sql);
					while($row = $result-> fetch_assoc()){
						$first = $row['first_name'];
						$last = $row['last_name'];

						echo "<br><br>";
						echo'<span style="font-size:3.25em;color:white;font-weight:bold;">'.$first.'</span>';
						echo "  ";
						echo'<span style="font-size:3.25em;color:white;font-weight:bold;">'.$last.'</span>';
				}
				?>

			</div>
		</div>
		<!-- // navbar -->

		<!-- Page content -->
		
		
	<div class="change_header">
	<h2>Change Address</h2>
	</div>
	
	<form action="changeaddress.php" method = "POST">
	
		<?php include('errors.php'); ?>
		
		<div class="change_address">
			<label>Street Address</label>
			<input type="text" name = "street" value="<?php echo $street; ?>">
		</div>
		<div class="change_address">
			<label>State</label>
			<input type="text" name = "state" value="<?php echo $state; ?>">
		</div>
		<div class="change_address">
			<label>Zip Code</label>
			<input type="int" name = "zip" value="<?php echo $zip; ?>">
		</div>
		
		<div class="change_address">
			<button type="submit" name = "change" class="btn">Save Changes</button >
		</div>
		<div class="change_address">
			<button type="submit" name = "cancel" class="btn">Cancel Changes</button >
		</div>
	</form>
		
		<!-- // Page content -->

	</div>
	<!-- // container -->
</body>
</html>
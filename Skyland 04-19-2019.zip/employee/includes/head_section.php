<!DOCTYPE html>
<html>
<head>
		<!-- Styling for public area -->
	<link rel="stylesheet" href="stylesheets/style_employee.css">
	<meta charset="UTF-8">
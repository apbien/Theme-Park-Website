<?php  include('../config.php'); ?>
<!DOCTYPE html>

<html>
<head>
		<!-- Styling for public area -->
	<link rel="stylesheet" href="includes/style_employee.css">
	<meta charset="UTF-8">
	<title> Employee Home Page </title>
</head>
<body>
	<!-- container - wraps whole page -->
	<div class="container">
		<!-- navbar -->
		<div class="navbar">

			<?php

			
			$time = strtotime("-16 year", time());
			$date = date("Y-m-d", $time);

			if($_SESSION['bday'] > $date ){
				echo "<script type='text/javascript'>alert('Trigger Activated, Employee Younger Than 16, User Not 					Inserted Into Database!, Logging Out')</script>";
				echo "<script>setTimeout(\"location.href = '../Logout.php';\",1500);</script>";
			}

			if ( in_array($_SESSION['employee']['manager_status'], ["A","Y"])){
			echo '<div class="buttons">
				<ul>
					<li><a href="../admin/dashboard.php">Admin Page</a></li>
					<li><a href="../index.php">Main Page</a></li>
					<li><a href="../logout.php">Logout </a> </li> 
				</ul>
			</div>';
			}
			else{
				echo '<div class="buttons">
				<ul>
					<li><a href="../index.php">Main Page</a></li>
					<li><a href="../logout.php">Logout </a> </li>
					<li><a href="employeesearch.php">Contact Employees</a></li> 
				</ul>
			</div>';
			}

			?>
		
			<div class="logo_div">

				<?php
				$id = "";
				$id = $_SESSION['employee']['email'];
					//CHANGE: for the line of code under this one, change (WHERE employee_id = 1) to the current logged in user
					$sql = "SELECT first_name,last_name FROM employee WHERE email= '$id'";
					$result = $conn-> query($sql);
					while($row = $result-> fetch_assoc()){
						$first = $row['first_name'];
						$last = $row['last_name'];

						echo "<br><br>";
						echo'<span style="font-size:3.25em;color:white;font-weight:bold;">'.$first.'</span>';
						echo "  ";
						echo'<span style="font-size:3.25em;color:white;font-weight:bold;">'.$last.'</span>';
				}
				?>

			</div>
		</div>
		<!-- // navbar -->

		<!-- Page content -->
		<div class="content">
			
			
			
			<!-- Address Portion -->
			<br>
			<div class="content-title">
				<h2>Address</h2>
			</div>
			<div class = "change-button">
				<ul>
					<li><a href="changeaddress.php">Change</a></li>
				</ul>
			</div>
			<div class="inline-block">
				<hr>
			</div>
			<?php
				$id = "";
				$id = $_SESSION['employee']['email'];
				//CHANGE: for the line of code under this one, change (WHERE employee_id = 1) to the current logged in user
				$sql = "SELECT street_address,state,zip_code FROM employee WHERE email= '$id'";
				$result = $conn-> query($sql);
				while($row = $result-> fetch_assoc()){
					echo "Street Address: ";
					echo "<tr><td>". $row["street_address"];
					echo "<br>";					
					echo "State: ";
					echo "<tr><td>". $row["state"];
					echo "<br>";
					echo "Zip Code: ";
					echo "<tr><td>". $row["zip_code"];
					echo "<br>";
				}
			?>
			
			<!--Position Information Poriton-->
			<br><br><br>
			<div class="content-title">
				<h2>Position</h2>
			</div>
			<div class="inline-block">
				<hr>
			</div>
			<?php
				$id = "";
				$id = $_SESSION['employee']['email'];
				//CHANGE: for the line of code under this one, change (WHERE employee_id = 1) to the current logged in user
				$sql = "SELECT hourly_wage,salary,hours,restaurant_id_fk,giftshop_id_fk,attraction_id_fk,maint_id_fk,marketing_id_fk,event_id_fk, manager_status FROM employee WHERE email= '$id'";
				$result = $conn-> query($sql);
				while($row = $result-> fetch_assoc()){
					//Next 9 if-statements checks to see what kind of employee they are
					if($row["restaurant_id_fk"] != ""){
						echo "Position: Restaurant Employee";
						echo "<br>";
					}
					if($row["giftshop_id_fk"] != ""){
						echo "Position: Giftshop Employee";
						echo "<br>";
					}
					if($row["attraction_id_fk"] != ""){
						echo "Position: Attraction Employee";
						echo "<br>";
					}
					if($row["maint_id_fk"] != ""){
						echo "Position: Maintenance Employee";
						echo "<br>";
					}
					if($row["marketing_id_fk"] != ""){
						echo "Position: Marketing Employee";
						echo "<br>";
					}
					if($row["event_id_fk"] != ""){
						echo "Position: Events Employee";
						echo "<br>";
					}
					if($row['manager_status'] == 'A'){
						echo "Position: Admin";
						echo "<br>";
					}
					if($row['manager_status'] == 'Y'){
						echo "Position: Manager";
						echo "<br>";
					}

					if($row["restaurant_id_fk"] == NULL AND $row["giftshop_id_fk"] == NULL AND $row["attraction_id_fk"] == NULL AND $row["maint_id_fk"] == NULL AND $row["marketing_id_fk"] == NULL AND $row["event_id_fk"] == NULL){
						echo "Position: None";
						echo "<br>";
					}
					//Next two if-statements: checks to output either hourly wage or salary
					if($row["hourly_wage"] != ""){
						echo "Hourly Wage: ";
						echo "<tr><td>". $row["hourly_wage"];
						echo "<br>";
					}
					if($row["salary"] != ""){
						echo "Salary: ";
						echo "<tr><td>". $row["salary"];
						echo "<br>";			
					}
					echo "Hours Currently Worked: ";
					echo "<tr><td>". $row["hours"];
					echo "<br>";
				}
			?>
			
			<!--Location of Assignment Poriton-->
			<br><br><br>
			<div class="content-title">
				<h2>Location of Assignment</h2>
			</div>
			<div class="inline-block">
				<hr>
			</div>
			<?php
				$id = "";
				$id = $_SESSION['employee']['email'];
				//CHANGE: for the line of code under this one, change (WHERE employee_id = 1) to the current logged in user
				$sql = "SELECT hourly_wage,salary,hours,restaurant_id_fk,giftshop_id_fk,attraction_id_fk,maint_id_fk,marketing_id_fk,event_id_fk, manager_status FROM employee WHERE email= '$id'";
				$result = $conn-> query($sql);
				while($row = $result-> fetch_assoc()){
				
					if($row["restaurant_id_fk"] != ""){
						//CHANGE: for the line of code under this one, change (WHERE employee_id = 1) to the current logged in user
						$sql2 = "SELECT restaurant.restaurant_id,restaurant.location_id_fk, restaurant.restaurant_name FROM employee JOIN restaurant ON employee.restaurant_id_fk = restaurant.restaurant_id WHERE employee.email= '$id'";
						$result2 = $conn-> query($sql2);
						while($row2 = $result2-> fetch_assoc()){
							echo "Restaurant ID: ";
							echo "<tr><td>". $row2["restaurant_id"];
							echo "<br>";
							echo "Restaurant Name: ";
							echo "<tr><td>". $row2["restaurant_name"];
							echo "<br>";
							echo "Park Location: ";
							echo "<tr><td>". $row2["location_id_fk"];
							echo "<br>";
						}
					}
					if($row["giftshop_id_fk"] != ""){
						//CHANGE: for the line of code under this one, change (WHERE employee_id = 1) to the current logged in user
						$sql2 = "SELECT gift_shop.giftshop_id,gift_shop.location_id_fk, gift_shop.giftshop_name FROM employee JOIN gift_shop ON employee.giftshop_id_fk = gift_shop.giftshop_id WHERE employee.email= '$id'";
						$result2 = $conn-> query($sql2);
						while($row2 = $result2-> fetch_assoc()){
							echo "Giftshop ID: ";
							echo "<tr><td>". $row2["giftshop_id"];
							echo "<br>";
							echo "Giftshop Name: ";
							echo "<tr><td>". $row2["giftshop_name"];
							echo "<br>";
							echo "Park Location: ";
							echo "<tr><td>". $row2["location_id_fk"];
							echo "<br>";
						}
					}
					if($row["attraction_id_fk"] != ""){
						//CHANGE: for the line of code under this one, change (WHERE employee_id = 1) to the current logged in user
						$sql2 = "SELECT attraction.ride_id,attraction.location_id_fk, attraction.name FROM employee JOIN attraction ON employee.attraction_id_fk = attraction.ride_id WHERE employee.email= '$id'";
						$result2 = $conn-> query($sql2);
						while($row2 = $result2-> fetch_assoc()){
							echo "Ride ID: ";
							echo "<tr><td>". $row2["ride_id"];
							echo "<br>";
							echo "Ride Name: ";
							echo "<tr><td>". $row2["ride_name"];
							echo "<br>";
							echo "Park Location: ";
							echo "<tr><td>". $row2["location_id_fk"];
							echo "<br>";
						}
					}
					if($row["maint_id_fk"] != ""){
						//CHANGE: for the line of code under this one, change (WHERE employee_id = 1) to the current logged in user
						$sql2 = "SELECT maintenance_schedules.maintenance_id FROM employee JOIN maintenance_schedules ON employee.maint_id_fk = maintenance_schedules.maintenance_id WHERE employee.email= '$id'";
						$result2 = $conn-> query($sql2);
						while($row2 = $result2-> fetch_assoc()){
							echo "Maintenance ID: ";
							echo "<tr><td>". $row2["maintenance_id"];
							echo "<br>";
						}
					}
					if($row["marketing_id_fk"] != ""){
						//CHANGE: for the line of code under this one, change (WHERE employee_id = 1) to the current logged in user
						$sql2 = "SELECT marketing.marketing_id,marketing.advertisement_type FROM employee JOIN marketing ON employee.marketing_id_fk = marketing.marketing_id WHERE employee.email= '$id'";
						$result2 = $conn-> query($sql2);
						while($row2 = $result2-> fetch_assoc()){
							echo "Marketing ID: ";
							echo "<tr><td>". $row2["marketing_id"];
							echo "<br>";
							echo "Advertisement Type: ";
							echo "<tr><td>". $row2["advertisement_type"];
							echo "<br>";
						}
					}
					if($row["event_id_fk"] != ""){
						//CHANGE: for the line of code under this one, change (WHERE employee_id = 1) to the current logged in user
						$sql2 = "SELECT events.event_id,venue.location_id_fk, venue.venue_name FROM employee JOIN events ON employee.event_id_fk = events.event_id JOIN venue ON events.venue_id_fk = venue.venue_id WHERE employee.email= '$id'";
						$result2 = $conn-> query($sql2);
						while($row2 = $result2-> fetch_assoc()){
							echo "Event ID: ";
							echo "<tr><td>". $row2["event_id"];
							echo "<br>";
							echo "Venue Name: ";
							echo "<tr><td>". $row2["venue_name"];
							echo "<br>";
							echo "Park Location: ";
							echo "<tr><td>". $row2["location_id_fk"];
							echo "<br>";
						}
					}
					if($row['manager_status'] =='A' ){
						echo "In this network.";
						echo "<br>";
					}
					if($row['manager_status'] =='Y' ){
						echo "Everywhere.";
						echo "<br>";
					}
				}
				$conn->close();
			?>
		</div>
		
		<!-- // Page content -->

	</div>
	<!-- // container -->
</body>
</html>
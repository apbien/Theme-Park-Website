<?php 
	session_start();
	session_unset($_SESSION['employee']);
	session_destroy();
	header('location: index.php');
?>
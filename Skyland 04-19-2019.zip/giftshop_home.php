	<!-- ROOT PATH IS SET TO PHYSICAL ADDRESS-->
<?php require_once('config.php') ?>
<!-- config.php should be here as the first include  -->

<?php require_once( ROOT_PATH . '/includes/public_functions.php') ?>

<!-- Retrieve all rides from database, get Attraction function -->
<?php $gifts = getgiftShops(); ?>
<?php require_once('includes/head_section.php') ?>

		<!-- navbar -->
			<?php include( ROOT_PATH . '/includes/navbar.php') ?>
				<!-- // navbar -->

<!-- Next Section  -->

		<div class="content">
			<h2 class="content-title">Gift Shops</h2>
			<hr>
			<!-- more content still to come here ... -->

			<!-- Add this ... -->
		<?php foreach ($gifts as $gift): ?>
		<div class="post" style="margin-left: 5px;">
				<div class="gift_info">
					<h3><?php echo $gift['giftshop_name'] ?></h3>
					<div class="info">
						<label>Merchandise List:</label>
						<p><?php echo $gift['merchandise_list'] ?></p>
						<label>Opening Time:</label>
						<p><?php echo $gift['opening_time'] ?></p>
						<label>Closing Time:</label>
						<p><?php echo $gift['closing_time'] ?></p>
						<label>Park Location: </label>
						<p><?php echo $gift['location_id_fk'] ?></p>

					</div>
				</div>
		</div>
		<?php endforeach ?>
		</div>

	<!-- footer -->
<?php include( ROOT_PATH . '/includes/footer.php') ?>